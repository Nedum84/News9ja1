package com.jambpostutmeaskme

//class Item(var name: String = "", var type: Int = 0)