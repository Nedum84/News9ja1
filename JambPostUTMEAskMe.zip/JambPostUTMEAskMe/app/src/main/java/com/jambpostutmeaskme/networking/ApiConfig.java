package com.jambpostutmeaskme.networking;


import java.util.Map;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;


public interface ApiConfig {

    @Multipart
    @POST("server_request/add_question_with_image.php")
    Call<ServerResponse> upload(
            @Header("Authorization") String authorization,
            @PartMap Map<String, RequestBody> map,
            @Part("request_type") String request_type,
            @Part("message_body") String message_body,
            @Part("option_a") String option_a,
            @Part("option_b") String option_b,
            @Part("option_c") String option_c,
            @Part("option_d") String option_d,
            @Part("subject_id") String subject_id,
            @Part("topic_id") String topic_id,
            @Part("answer_id") String answer_id,
            @Part("question_type") String question_type,
            @Part("exam_type") String exam_type,
            @Part("school_id") String school_id,
            @Part("poster_id") String poster_id
    );
}