package com.jambpostutmeaskme

import android.app.PendingIntent.getActivity
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main3.*
import android.graphics.RectF
import com.isseiaoki.simplecropview.callback.LoadCallback
import android.os.AsyncTask.execute
import android.graphics.Bitmap
import android.net.Uri
import com.isseiaoki.simplecropview.callback.CropCallback
import com.isseiaoki.simplecropview.callback.SaveCallback
import java.io.File
import android.provider.MediaStore
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*
import com.isseiaoki.simplecropview.CropImageView
import kotlinx.android.synthetic.main.alert_dialog_inflate_sure_to_scan.view.*


class Main3Activity : AppCompatActivity(), View.OnClickListener {

    private val mFrameRect: RectF? = null
    private val mCompressFormat = Bitmap.CompressFormat.JPEG
    lateinit var mSourceUri:Uri
    lateinit var progresDialog:ClassProgressDialog
    lateinit var outputFilePath:String

    lateinit var thisContext: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        setSupportActionBar(toolbar)
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowHomeEnabled(true)
        thisContext = this
        progresDialog = ClassProgressDialog(thisContext,"Saving, please wait...")
        if(ClassSharePreference(thisContext).getQImgUrl() !=""){
            mSourceUri = Uri.fromFile(File(ClassSharePreference(thisContext).getQImgUrl()))
            ClassSharePreference(thisContext).setScanCheck("")//set empty on loading
        }else{
            super.onBackPressed()
        }

//        mSourceUri = Uri.fromFile(File("/sdcard/sample.jpg"))
        bindViews()
        // load image
        mCropView.load(mSourceUri)
                .initialFrameRect(mFrameRect)
                .useThumbnail(true)
                .execute(mLoadCallback)

    }
    fun cropImage(){
        progresDialog.createDialog()
        mCropView.crop(mSourceUri).execute(object : CropCallback {
            override fun onSuccess(cropped: Bitmap) {
                mCropView.save(cropped).execute(createSaveUri(), mSaveCallback)
            }

            override fun onError(e: Throwable) {}
        })

    }
    private val mLoadCallback = object : LoadCallback {
        override fun onSuccess() {
            Toast.makeText(thisContext, "Crop your image...", Toast.LENGTH_SHORT).show()
        }

        override fun onError(e: Throwable) {
            Toast.makeText(thisContext, "Error occurred, try again...", Toast.LENGTH_SHORT).show()
        }
    }

    private val mSaveCallback = object : SaveCallback {
        override fun onSuccess(uri: Uri?) {
            progresDialog.dismissDialog()
            ClassSharePreference(thisContext).setQImgUrl(outputFilePath)
            finish()
            backPressed()
        }

        override fun onError(e: Throwable?) {
            progresDialog.dismissDialog()
        }
    }
    fun backPressed(){
        super.onBackPressed()
    }
    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right)
    }
    override fun onClick(v: View?) {
        when (v!!.id) {
            R.id.buttonDone -> cropImage()
            R.id.buttonFitImage -> mCropView.setCropMode(CropImageView.CropMode.FIT_IMAGE)
            R.id.button1_1 -> mCropView.setCropMode(CropImageView.CropMode.SQUARE)
            R.id.button3_4 -> mCropView.setCropMode(CropImageView.CropMode.RATIO_3_4)
            R.id.button4_3 -> mCropView.setCropMode(CropImageView.CropMode.RATIO_4_3)
            R.id.button9_16 -> mCropView.setCropMode(CropImageView.CropMode.RATIO_9_16)
            R.id.button16_9 -> mCropView.setCropMode(CropImageView.CropMode.RATIO_16_9)
            R.id.buttonCustom -> mCropView.setCustomRatio(7, 5)
            R.id.buttonFree -> mCropView.setCropMode(CropImageView.CropMode.FREE)
            R.id.buttonCircle -> mCropView.setCropMode(CropImageView.CropMode.CIRCLE)
            R.id.buttonShowCircleButCropAsSquare -> mCropView.setCropMode(CropImageView.CropMode.CIRCLE_SQUARE)
            R.id.buttonRotateLeft -> mCropView.rotateImage(CropImageView.RotateDegrees.ROTATE_M90D)
            R.id.buttonRotateRight -> mCropView.rotateImage(CropImageView.RotateDegrees.ROTATE_90D)
            R.id.buttonScanTextFromImage -> showScanDialog()
            else ->{
                super.onBackPressed()
            }
        }
    }
    private fun showScanDialog(){

        val inflater = LayoutInflater.from(thisContext).inflate(R.layout.alert_dialog_inflate_sure_to_scan, null)
        val builder = AlertDialog.Builder(thisContext)

        builder.setView(inflater)
        val dialog = builder.create()
        dialog.show()
        inflater.scanTextBtn.setOnClickListener {
            if (inflater.discardImageAfterScanCheckBox.isChecked){
                ClassSharePreference(thisContext).setScanCheck("discard")
            }else{
                ClassSharePreference(thisContext).setScanCheck("no_discard")
            }
            dialog.dismiss()
            super.onBackPressed()
        }
    }
    private fun bindViews() {
        buttonDone.setOnClickListener(this)
        buttonFitImage.setOnClickListener(this)
        button1_1.setOnClickListener(this)
        button3_4.setOnClickListener(this)
        button4_3.setOnClickListener(this)
        button9_16.setOnClickListener(this)
        button16_9.setOnClickListener(this)
        buttonFree.setOnClickListener(this)
        buttonScanTextFromImage.setOnClickListener(this)
        buttonRotateLeft.setOnClickListener(this)
        buttonRotateRight.setOnClickListener(this)
        buttonCustom.setOnClickListener(this)
        buttonCircle.setOnClickListener(this)
        buttonShowCircleButCropAsSquare.setOnClickListener(this)
    }
    fun createSaveUri(): Uri {
        return createNewUri(this, mCompressFormat)!!
    }

    private fun createNewUri(context: Context, format: Bitmap.CompressFormat): Uri? {
        val currentTimeMillis = System.currentTimeMillis()
        val today = Date(currentTimeMillis)
        val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss")
        val title = dateFormat.format(today)
        val dirPath = getDirPath()
        val fileName = "scv" + title + "." + getMimeType(format)
        val path = dirPath + "/" + fileName
        outputFilePath = path
        val file = File(path)
        val values = ContentValues()
        values.put(MediaStore.Images.Media.TITLE, title)
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/" + getMimeType(format))
        values.put(MediaStore.Images.Media.DATA, path)
        val time = currentTimeMillis / 1000
        values.put(MediaStore.MediaColumns.DATE_ADDED, time)
        values.put(MediaStore.MediaColumns.DATE_MODIFIED, time)
        if (file.exists()) {
            values.put(MediaStore.Images.Media.SIZE, file.length())
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        Log.d("SaveUri =", uri!!.toString())
        return uri
    }

    private fun getMimeType(format: Bitmap.CompressFormat): String {
//        Logger.i("getMimeType CompressFormat = $format")
        when (format) {
            Bitmap.CompressFormat.JPEG -> return "jpeg"
            Bitmap.CompressFormat.PNG -> return "png"
            else -> {

            }
        }
        return "png"
    }

    private fun getDirPath(): String {
        var dirPath = ""
        var imageDir: File? = null
        val extStorageDir = Environment.getExternalStorageDirectory()
        if (extStorageDir.canWrite()) {
            imageDir = File(extStorageDir.path + "/simplecropview")
        }
        if (imageDir != null) {
            if (!imageDir.exists()) {
                imageDir.mkdirs()
            }
            if (imageDir.canWrite()) {
                dirPath = imageDir.path
            }
        }
        return dirPath
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_crop, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                super.onBackPressed()
            }
            R.id.menu_action_crop ->{
                showScanDialog()
            }
            R.id.menu_action_crop2 ->{
                showScanDialog()
            }
            R.id.menu_action_save_cropped_img ->{
                cropImage()
            }
            else -> return super.onOptionsItemSelected(item)
        }

        return true
    }

}
