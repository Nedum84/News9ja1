package com.jambpostutmeaskme

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.os.Bundle
import android.support.v4.content.ContextCompat.startActivity
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.adapter_design_cbt_questions.view.*
import kotlinx.android.synthetic.main.adapter_design_question_answers.view.*
import kotlinx.android.synthetic.main.list_item_progressbar.view.*
import kotlinx.android.synthetic.main.adapter_design_questions.view.*
import org.json.JSONException
import org.json.JSONObject
import java.util.ArrayList
import java.util.HashMap

class ItemArrayAdapter(private var itemList: ArrayList<Item> = ArrayList()) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val REGULAR_ITEM = 0
    val FOOTER_ITEM = 1

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun getItemViewType(position: Int): Int {
        val item = itemList[position]
        if (item.type == REGULAR_ITEM) {
            return REGULAR_ITEM
        } else if (item.type == FOOTER_ITEM) {
            return FOOTER_ITEM
        }
        throw Exception("Error, unknown view type")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == REGULAR_ITEM) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
            return RegularViewHolder(view)
        } else if (viewType == FOOTER_ITEM) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item_progressbar, parent, false)
            return FooterViewHolder(view)
        } else {
            throw RuntimeException("The type has to be ONE or TWO")
        }
    }

    // load data in each row element
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder.itemViewType) {
            REGULAR_ITEM -> {
                holder as RegularViewHolder
                holder.item.text = itemList[position].name
            }
            FOOTER_ITEM -> {
                // no data need to be assigned
            }
            else -> {
                // no data need to be assigned
            }
        }
    }

    // this is required to be called right before loading more items
    fun addFooter() {
        Log.d("endlessscroll", "addFooter")
        if (!isLoading()) {
            itemList.add(Item("Footer", 1))
            notifyItemInserted(itemList.size - 1)
        }
    }

    // this is required to be called right after finish loading the items
    fun removeFooter() {
        Log.d("endlessscroll", "removeFooter")
        if (isLoading()) {
            itemList.removeAt(itemList.size - 1)
            notifyItemRemoved(itemList.size - 1)
        }
    }

    // it is loading if the last item is footer
    fun isLoading() : Boolean {
        return itemList.last().type == FOOTER_ITEM
    }

    fun addItems(items : ArrayList<Item>) {
        val lastPos = itemList.size - 1
        itemList.addAll(items)
        notifyItemRangeInserted(lastPos, items.size)
    }

    inner class RegularViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        var item: TextView

        init {
            itemView.setOnClickListener(this)
            item = itemView.findViewById<View>(R.id.textview) as TextView
        }

        override fun onClick(view: View) {
            Log.d("onclick", "onClick " + layoutPosition + " " + item.text)
        }
    }

    inner class FooterViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var progressBar = itemView.progressbar
    }
}

class QuestionsAdapter(items:MutableList<QuestionDataClassBinder>, ctx: Context) : RecyclerView.Adapter<QuestionsAdapter.ViewHolder>() {

    var list = items
    var context = ctx
    var sqLiteDBHelper = SQLiteDBHelper(context)
    private var adapterCallbackInterface: QuestionsAdapterCallbackInterface? = null

    val REGULAR_ITEM = 0
    val FOOTER_ITEM = 1

    private var bgColorList = mutableListOf("#d9b51c","#cd8313","#0067A3","#519839","#F6696C","#0079BF","#064e71")

    init {
        try {
            adapterCallbackInterface = context as QuestionsAdapterCallbackInterface
        } catch (e: ClassCastException) {
            throw RuntimeException(context.toString() + "Activity must implement QuestionsAdapterCallbackInterface.", e)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun getItemViewType(position: Int): Int {
        val item = list[position]
        if (item.type == REGULAR_ITEM) {
            return REGULAR_ITEM
        } else if (item.type == FOOTER_ITEM) {
            return FOOTER_ITEM
        }
        throw Exception("Error, unknown view type")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        if (viewType == REGULAR_ITEM) {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.adapter_design_questions, parent, false)
        return ViewHolder(view)
//        } else if (viewType == FOOTER_ITEM) {
//            val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item_progressbar, parent, false)
//            return FooterViewHolder(view)
//        } else {
//            throw RuntimeException("The type has to be ONE or TWO")
//        }
    }

    // this is required to be called right before loading more items
    fun addFooter() {
        Log.d("endlessscroll", "addFooter")
        if (!isLoading()) {
            list.add(QuestionDataClassBinder("Footer","Footer","Footer","Footer","Footer",
                    "Footer","Footer","Footer","Footer","Footer","Footer","Footer","Footer"
                    ,"Footer","Footer","Footer",1))
            notifyItemInserted(list.size - 1)
        }
    }

    // this is required to be called right after finish loading the items
    fun removeFooter() {
        Log.d("endlessscroll", "removeFooter")
        if (isLoading()) {
            list.removeAt(list.size - 1)
            notifyItemRemoved(list.size - 1)
        }
    }

    // it is loading if the last item is footer
    fun isLoading() : Boolean {
        return list.last().type == FOOTER_ITEM
    }

    fun addItems(items: MutableList<QuestionDataClassBinder>) {
        val lastPos = list.size - 1
        list.addAll(items)
        notifyItemRangeInserted(lastPos, items.size)

//        list.addAll(items)
//        this.notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val questionDetails = list[position]

        holder.qSubOrTopic.text = questionDetails.question_sub_or_topic

        holder.qPostedTime.text = ClassDateAndTime().checkDateTimeFirst(questionDetails.q_posted_time!!.toLong())
        holder.qPostedTime.text = questionDetails.question_id
        holder.qBody.text = ClassHtmlFormater().fromHtml(questionDetails.q_body)
//        holder.qBody.text = questionDetails.question_type+"-"+questionDetails.question_id

        holder.qPoster.text = questionDetails.q_poster
        holder.qNoOfAnswers.text = questionDetails.q_no_of_answers
        holder.qNoOfLikes.text = questionDetails.q_top_ans_no_of_likes+" Likes"
        holder.qTopAnswerPoster.text = questionDetails.q_top_ans_poster
        holder.qTopAnswerBody.text = ClassHtmlFormater().fromHtml(questionDetails.q_top_ans_body)

        if (questionDetails.q_img_path == ""||questionDetails.q_img_path =="null"){
            holder.qImgPath.visibility = View.GONE
        }else{
            holder.qImgPath.visibility = View.VISIBLE
            Glide.with(context)
                    .load(questionDetails.q_img_path)
                    .apply(RequestOptions()
//                            .placeholder(R.drawable.q_mark1)//default image on loading
                            .error(R.drawable.q_mark1)//without n/w, this img shows
                            .fitCenter()
                            .dontAnimate()
                            .dontTransform()
                    )
                    .into(holder.qImgPath)
        }

        if (sqLiteDBHelper.checkIfQuestionIsSaved(questionDetails.question_id.toInt())){//saved
            holder.savedBtn.visibility = View.VISIBLE
            holder.saveBtn.visibility = View.GONE
        }else{
            holder.saveBtn.visibility = View.VISIBLE
            holder.savedBtn.visibility = View.GONE
        }

        holder.saveBtn.setOnClickListener{
            //update DB
            sqLiteDBHelper.saveQuestion(questionDetails.question_id)

            holder.saveBtn.visibility = View.GONE
            holder.savedBtn.visibility = View.VISIBLE
        }
        holder.savedBtn.setOnClickListener{
            //update DB
            sqLiteDBHelper.deleteSavedQuestion(questionDetails.question_id)

            holder.savedBtn.visibility = View.GONE
            holder.saveBtn.visibility = View.VISIBLE

        }
        holder.qSubOrTopic.setOnClickListener{
            val subjectList = sqLiteDBHelper.getSubjects()
            val subjectsNameArray = arrayListOf<String>()

            for (element in subjectList) {
                subjectsNameArray.add(element.subject_name!!.toLowerCase())
            }
            val checkingSub = subjectsNameArray.contains(questionDetails.question_sub_or_topic!!.toLowerCase())
            if(checkingSub){//it's subject clicked
                ClassSharePreference(context).reset()
                ClassSharePreference(context).setCurrentSubjectId(questionDetails.subject_id)
                ClassSharePreference(context).setCurrentSubjectName(questionDetails.subject_name)
                ClassSharePreference(context).setCurrentTopicName(questionDetails.topic_name)

//                startActivity(context,Intent(context, ActivityQuestionView::class.java), Bundle())
                adapterCallbackInterface!!.onReloadCallback()
            }else{//topic clicked
                ClassSharePreference(context).reset()
                ClassSharePreference(context).setCurrentTopicId(questionDetails.topic_id)
                ClassSharePreference(context).setCurrentSubjectName(questionDetails.subject_name)
                ClassSharePreference(context).setCurrentTopicName(questionDetails.topic_name)

//                startActivity(context,Intent(context, ActivityQuestionView::class.java), Bundle())
                adapterCallbackInterface!!.onReloadCallback()
            }

        }
        holder.qPoster.setOnClickListener{
            ClassSharePreference(context).reset()
            ClassSharePreference(context).setPosterId(questionDetails.q_poster_id!!)
            ClassSharePreference(context).setPosterName(questionDetails.q_poster!!)
            ClassSharePreference(context).setCurrentSubjectName(questionDetails.subject_name)
            ClassSharePreference(context).setCurrentTopicName(questionDetails.topic_name)

            adapterCallbackInterface!!.onReloadCallback()
        }
        holder.qListWrapper.setOnClickListener {
            ClassSharePreference(context).setCurrentQuestionId(questionDetails.question_id)
            ClassSharePreference(context).setCurrentSubjectName(questionDetails.subject_name)
            ClassSharePreference(context).setCurrentTopicName(questionDetails.topic_name)
            startActivity(context,Intent(context, ActivityQuestionSolutions::class.java), Bundle())
        }

        //change bg color of the title
        val changeTitleBgColor = holder.qSubOrTopic.background.mutate()
        changeTitleBgColor.setColorFilter(Color.parseColor(bgColorList[(0 until bgColorList.size-1).shuffled().last()]), PorterDuff.Mode.SRC_IN)
    }
    open inner class ViewHolder(v: View): RecyclerView.ViewHolder(v), View.OnClickListener{
        override fun onClick(v: View?) {

        }
        val qSubOrTopic = v.qSubOrTopic!!
        val qPostedTime = v.qPostedTime!!
        val qImgPath = v.qImgPath!!
        val qBody = v.qBody!!
        val qPoster = v.qPoster!!
        val saveBtn = v.saveBtn!!
        val savedBtn = v.savedBtn!!
        val qNoOfAnswers = v.qNoOfAnswers!!
        val qNoOfLikes = v.qNoOfLikes!!
        val qTopAnswerPoster = v.qTopAnswerPoster!!
        val qTopAnswerBody = v.qTopAnswerBody!!
        val qListWrapper = v.qListWrapper!!

    }

    inner class FooterViewHolder(itemView: View) : ViewHolder(itemView) {
        var progressBar = itemView.progressbar
    }



    //interface declaration
    interface QuestionsAdapterCallbackInterface {
        fun onReloadCallback()
    }
}
class CBTQsAdapter(items:MutableList<ExamQDataClassBinder>, ctx: Context) : RecyclerView.Adapter<CBTQsAdapter.ViewHolder>() {

    var list = items
    var context = ctx
    var sqLiteDBHelper = SQLiteDBHelper(context)
    private var adapterCallbackInterface: QuestionsAdapterCallbackInterface? = null

    init {
        try {
            adapterCallbackInterface = context as QuestionsAdapterCallbackInterface
        } catch (e: ClassCastException) {
            throw RuntimeException(context.toString() + "Activity must implement AdapterCallbackInterface.", e)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.adapter_design_cbt_questions, parent, false)
        return ViewHolder(view)
    }

    fun addItems(items: MutableList<ExamQDataClassBinder>) {
        val lastPos = list.size - 1
        list.addAll(items)
        notifyItemRangeInserted(lastPos, items.size)

//        list.addAll(items)
//        this.notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val questionDetails = list[position]

        holder.questionNo.text = (position+0).toString()

        holder.questionAnsweredOption.text = questionDetails.user_answered_option

        holder.questionNoWrapper.setOnClickListener {
            adapterCallbackInterface?.onReloadCallback()
        }
        if (questionDetails.user_answered_option != "-1"){
            //change bg color of the title
            val changeWrapperBgColor = holder.questionNoWrapper.background.mutate()
            changeWrapperBgColor.setColorFilter(Color.parseColor("#222222"), PorterDuff.Mode.SRC_IN)

        }
    }
    open inner class ViewHolder(v: View): RecyclerView.ViewHolder(v){

        val questionNoWrapper = v.questionNoWrapper!!
        val questionNo = v.questionNo!!
        val questionAnsweredOption = v.questionAnsweredOption!!
    }




    //interface declaration
    interface QuestionsAdapterCallbackInterface {
        fun onReloadCallback()
    }
}

class AnswersAdapter(items:MutableList<AnswersDataClassBinder>, ctx: Context): RecyclerView.Adapter<AnswersAdapter.ViewHolder>(){
    //        private var bgColorList = mutableListOf("#d9b51c","#0067A3","#519839","#0079BF","#064e71")
    private var bgColorList = mutableListOf("#d9b51c","#cd8313","#0067A3","#519839","#F6696C","#0079BF","#064e71")
    private var list = items
    var context = ctx
    lateinit var voteBtnPos:TextView


    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(
                R.layout.adapter_design_question_answers,
                parent,
                false
        ))
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }
    fun addItems(items: MutableList<AnswersDataClassBinder>) {
        val lastPos = list.size - 1
        list.addAll(items)
        notifyItemRangeInserted(lastPos, items.size)


//        list.addAll(items)
//        this.notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val questionDetails = list[position]
        if (questionDetails.answer_type == "image"){
            Glide.with(context)
                    .load(questionDetails.answer_img_path)
                    .apply(RequestOptions()
//                            .placeholder(R.drawable.q_mark1)//default image on loading
                            .error(R.drawable.q_mark1)//without n/w, this img shows
                            .fitCenter()
                            .dontAnimate()
                            .dontTransform()
                    )
//                    .thumbnail(.1f)
                    .into(holder.ans_img_path)
        }
        holder.answerer.text     =questionDetails.answerer
        holder.ans_date.text = ClassDateAndTime().checkDateTimeFirst(questionDetails.answer_date!!.toLong())
        holder.no_of_likes.text = questionDetails.no_of_likes
        holder.no_of_dislikes.text = questionDetails.no_of_dislikes

        if (questionDetails.answer_msg_body==""){
            holder.ans_msg_body.visibility = View.GONE
        }else{
            holder.ans_msg_body.text = ClassHtmlFormater().formatTags((questionDetails.answer_msg_body!!))
        }
        if (questionDetails.vote_status=="like"){
            holder.like_or_dislike_notice.visibility = View.VISIBLE
            holder.like_or_dislike_notice.text = "You liked this"
        }else if (questionDetails.vote_status=="dislike"){
            holder.like_or_dislike_notice.visibility = View.VISIBLE
            holder.like_or_dislike_notice.text = "You disliked this"
        }else{
            holder.like_or_dislike_notice.visibility = View.GONE
        }


        holder.likeBtn.setOnClickListener {
            voteBtnPos = holder.like_or_dislike_notice
            if (questionDetails.vote_status == "like"){
                Toast.makeText(context, "Already Liked this Answer...", Toast.LENGTH_SHORT).show()
            }else if (questionDetails.vote_status == "dislike"){
                Toast.makeText(context, "Already Disliked this Answer...", Toast.LENGTH_SHORT).show()
            }else{
                sendVote("1", questionDetails.answer_id!!,holder.no_of_likes,holder.no_of_dislikes)
            }
        }
        holder.dislikeBtn.setOnClickListener {
            voteBtnPos = holder.like_or_dislike_notice
            if (questionDetails.vote_status == "like"){
                Toast.makeText(context, "Already Liked this Answer...", Toast.LENGTH_SHORT).show()
            }else if (questionDetails.vote_status == "dislike"){
                Toast.makeText(context, "Already Disliked this Answer...", Toast.LENGTH_SHORT).show()
            }else{
                sendVote("0", questionDetails.answer_id!!,holder.no_of_likes,holder.no_of_dislikes)
            }
        }
        holder.answerer.setOnClickListener {
            ClassSharePreference(context).reset()
            ClassSharePreference(context).setPosterId(questionDetails.answerer_id!!)
            ClassSharePreference(context).setPosterName(questionDetails.answerer!!)

            startActivity(context,Intent(context, ActivityQuestionView::class.java), Bundle())
        }

        //change bg color of answerer view
        val changeAnswererBgColor = holder.answerer.background.mutate()
        changeAnswererBgColor.setColorFilter(Color.parseColor(bgColorList[(0 until bgColorList.size-1).shuffled().last()]), PorterDuff.Mode.SRC_IN)
    }


    inner class ViewHolder(v: View): RecyclerView.ViewHolder(v){
        val answerer        = v.answerer!!
        val ans_date        = v.ans_date!!
        val ans_img_path    = v.ans_img_path!!
        val ans_msg_body    = v.ans_msg_body!!
        val likeBtn         = v.likeBtn!!
        val no_of_likes     = v.no_of_likes!!
        val dislikeBtn      = v.dislikeBtn!!
        val no_of_dislikes  = v.no_of_dislikes!!
        val like_or_dislike_notice = v.like_or_dislike_notice!!

    }


    private fun  sendVote(vote_status:String,answer_id:String,likeCounter:TextView,dislikeCounter:TextView){

        //volley interactions start
        //creating volley string request
        val progressDialog = ClassProgressDialog(context)
        progressDialog.createDialog()
        val stringRequest =  object : StringRequest(Request.Method.POST, UrlHolder.URL_SUBMIT_VOTING,
                Response.Listener<String> { response ->
                    progressDialog.dismissDialog()

                    try {
                        val obj = JSONObject(response)
                        val responseMsg = obj.getString("message")

                        if (responseMsg=="ok") {
                            if (vote_status == "1"){
                                Toast.makeText(context, "You Liked this Answer...", Toast.LENGTH_SHORT).show()
                                likeCounter.text = ((likeCounter.text).toString().toInt()+1).toString()
                                voteBtnPos.visibility = View.VISIBLE
                                voteBtnPos.text = "You liked this"
                            }else {
                                Toast.makeText(context, "You Disliked this Answer...", Toast.LENGTH_SHORT).show()
                                dislikeCounter.text = ((dislikeCounter.text).toString().toInt()+1).toString()
                                voteBtnPos.visibility = View.VISIBLE
                                voteBtnPos.text = "You disliked this"
                            }

                        }else{
                            Toast.makeText(context, responseMsg, Toast.LENGTH_SHORT).show()

                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Toast.makeText(context, e.printStackTrace().toString() + " Error", Toast.LENGTH_SHORT).show()
                    }
                },
                Response.ErrorListener { volleyError ->
                    progressDialog.dismissDialog()
                    Toast.makeText(context, volleyError.message, Toast.LENGTH_LONG).show()
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params["request_type"] = "add_vote"
                params["answer_id"] = answer_id
                params["question_id"] = ClassSharePreference(context).getCurrentQuestionId()
                params["user_id"] = ClassSharePreference(context).getUserDetails("id")
                params["like_or_unlike"] = vote_status
                return params
            }
        }
        //adding request to queue
        VolleySingleton.instance?.addToRequestQueue(stringRequest)
        //volley interactions end
    }

}
class QuestionsAdapters(items:MutableList<QuestionDataClassBinder>, ctx: Context): RecyclerView.Adapter<QuestionsAdapters.ViewHolder>(){

    var list = items
    var context = ctx
    var sqLiteDBHelper = SQLiteDBHelper(context)
    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(
                R.layout.adapter_design_questions,
                parent,
                false
        ))
    }

    override fun getItemCount(): Int {
        return list.size
    }
    fun updateItems(newList: MutableList<QuestionDataClassBinder> ) {
//            list.clear()
        list.addAll(newList)
        this.notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val questionDetails = list[position]

        holder.qSubOrTopic.text = questionDetails.question_sub_or_topic
        holder.qPostedTime.text = ClassDateAndTime().checkDateTimeFirst(questionDetails.q_posted_time!!.toLong())
        holder.qBody.text = ClassHtmlFormater().fromHtml(questionDetails.q_body)
        holder.qPoster.text = questionDetails.q_poster
        holder.qNoOfAnswers.text = questionDetails.q_no_of_answers
        holder.qNoOfLikes.text = questionDetails.q_top_ans_no_of_likes+" Likes"
        holder.qTopAnswerPoster.text = questionDetails.q_top_ans_poster
        holder.qTopAnswerBody.text = ClassHtmlFormater().fromHtml(questionDetails.q_top_ans_body)

        if (questionDetails.question_type == "image"){
            Glide.with(context)
                    .load(questionDetails.q_img_path)
                    .apply(RequestOptions()
                            .placeholder(R.drawable.ic_arrow_forward_black_24dp)//default image on loading
                            .error(R.drawable.ic_cloud_black_24dp)//without n/w, this img shows
                            .dontAnimate()
                            .fitCenter()
                    )
                    .thumbnail(.1f)
                    .into(holder.qImgPath)
        }

        if (sqLiteDBHelper.checkIfQuestionIsSaved(questionDetails.question_id.toInt())){//saved
            holder.saveBtn.visibility = View.VISIBLE
        }else{
            holder.savedBtn.visibility = View.VISIBLE
        }

        holder.saveBtn.setOnClickListener{
            //update DB
            sqLiteDBHelper.saveQuestion(questionDetails.question_id)

            holder.saveBtn.visibility = View.GONE
            holder.savedBtn.visibility = View.VISIBLE
        }
        holder.savedBtn.setOnClickListener{
            //update DB

            sqLiteDBHelper.deleteSavedQuestion(questionDetails.question_id)

            holder.savedBtn.visibility = View.GONE
            holder.saveBtn.visibility = View.VISIBLE

        }

    }


    inner class ViewHolder(v: View): RecyclerView.ViewHolder(v){
        val qSubOrTopic = v.qSubOrTopic!!
        val qPostedTime = v.qPostedTime!!
        val qImgPath = v.qImgPath!!
        val qBody = v.qBody!!
        val qPoster = v.qPoster!!
        val saveBtn = v.saveBtn!!
        val savedBtn = v.savedBtn!!
        val qNoOfAnswers = v.qNoOfAnswers!!
        val qNoOfLikes = v.qNoOfLikes!!
        val qTopAnswerPoster = v.qTopAnswerPoster!!
        val qTopAnswerBody = v.qTopAnswerBody!!

    }

}
class SchoolListAdapter(context: Context, private val viewResourceId: Int, private val schools: ArrayList<SchoolList>) : ArrayAdapter<SchoolList>(context, viewResourceId, schools) {
    private var itemsAll: ArrayList<SchoolList> = schools.clone() as ArrayList<SchoolList>
    private var suggestions: ArrayList<SchoolList> = ArrayList()

    private var nameFilter: Filter = object : Filter() {
        override fun convertResultToString(resultValue: Any): String {
            var scName =  (resultValue as SchoolList).school_name
            scName +=  "("+resultValue.school_code!!.toUpperCase()+")"
            return scName!!
        }

        override fun performFiltering(constraint: CharSequence?): Filter.FilterResults {
            if (constraint != null) {
                suggestions.clear()
                for (element in itemsAll) {
                    // Note: change the "contains" to "startsWith" if you only want starting matches
                    if ((element.school_name+"("+element.school_code+")").toLowerCase().contains(constraint.toString().toLowerCase())) {
                        suggestions.add(element)
                    }
                }
                val filterResults = Filter.FilterResults()
                filterResults.values = suggestions
                filterResults.count = suggestions.size
                return filterResults
            } else {
                return Filter.FilterResults()
            }
        }

        override fun publishResults(constraint:CharSequence?, results:FilterResults) {
            clear()
            if (results != null && results.count > 0){
                // we have filtered results
                addAll(results.values as ArrayList<SchoolList>)
            }
            notifyDataSetChanged()
        }


    }


    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var v = convertView
        if (v == null) {
            val vi = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            v = vi.inflate(viewResourceId, null)
        }
        val school = schools[position]
        if (school != null) {
            val school_name = v!!.findViewById(R.id.school_name) as TextView
            val school_logo = v.findViewById(R.id.school_logo) as ImageView
            val school_motto = v.findViewById(R.id.school_motto) as TextView
            school_name.text = school.school_name+"("+school.school_code!!.toUpperCase()+")"
            school_motto.text = school.school_motto
            Glide.with(context)
                    .load(school.school_logo)
                    .apply(RequestOptions()
                            .placeholder(R.drawable.ic_sms_black_24dp)//default image on loading
                            .fitCenter()
                    )
                    .thumbnail(.1f)
                    .into(school_logo)
        }
        return v!!
    }

    override fun getFilter(): Filter {
        return nameFilter
    }

}
