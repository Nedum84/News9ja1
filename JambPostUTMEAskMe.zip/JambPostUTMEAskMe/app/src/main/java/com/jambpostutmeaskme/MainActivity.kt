package com.jambpostutmeaskme

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.View
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONException
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private var questionsList: MutableList<QuestionDataClassBinder>? = mutableListOf()
    lateinit var thisContext: Context

    val linearLayoutManager = LinearLayoutManager(this)
    val itemList = ArrayList<Item>()
    lateinit var itemArrayAdapter : ItemArrayAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // initial list items
        for (i in 0..20) {
            itemList.add(Item("Item $i"))
        }

        itemArrayAdapter = ItemArrayAdapter(itemList)
        recyclerview.layoutManager = linearLayoutManager
        recyclerview.itemAnimator = DefaultItemAnimator()
        recyclerview.adapter = itemArrayAdapter

        recyclerview.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                // only load more items if it's currently not loading
                if (!itemArrayAdapter.isLoading()) {
                    // only load more items if the last visible item on the screen is the last item
                    Log.d("endlessscroll", "last visible position: ${linearLayoutManager.findLastCompletelyVisibleItemPosition()}, total count: ${linearLayoutManager.itemCount}")
                    if (linearLayoutManager.findLastCompletelyVisibleItemPosition() >= linearLayoutManager.itemCount - 1 ) {

                        // add progress bar, the loading footer
                        recyclerview.post {
                            itemArrayAdapter.addFooter()
                        }

                        // load more items after 2 seconds, and remove the loading footer
                        val handler = Handler()
                        handler.postDelayed({
                            itemArrayAdapter.removeFooter()
                            val newItems = ArrayList<Item>()
                            for (i in itemList.size..itemList.size + 19) {
                                newItems.add(Item("Item " + i))
                            }
                            itemArrayAdapter.addItems(newItems)
                        }, 2000)


                    }
                }
            }
        })

    }

    private fun loadQuestions(){
//        clearQuestionsCommentsDataClassBinder()
//        questions_container.layoutManager = LinearLayoutManager(this)

        //creating volley string request
//        question_loading_img?.visibility = View.VISIBLE
        val stringRequest = object : StringRequest(Request.Method.POST, UrlHolder.URL_GET_QUESTIONS,
                Response.Listener<String> { sub ->
//                    question_loading_img?.visibility = View.GONE

                    try {
                        val obj = JSONObject(sub)
                        if (!obj.getBoolean("error")) {
//                            questionsList!!.clear()
                            val noOfSub = obj.getJSONArray("topic_questionz_array")

                            if (noOfSub.length()!=0){
//                                no_question_div?.visibility = View.GONE

                                for (i in 0 until noOfSub.length()) {
                                    val objectSubject = noOfSub.getJSONObject(i)
                                    val subjectBinder = QuestionDataClassBinder(
                                            objectSubject.getString("question_id"),
                                            objectSubject.getString("subject_id"),
                                            objectSubject.getString("topic_id"),
                                            objectSubject.getString("subject_name"),
                                            objectSubject.getString("topic_name"),
                                            objectSubject.getString("question_sub_or_topic"),
                                            objectSubject.getString("question_type"),
                                            objectSubject.getString("q_posted_time"),
                                            objectSubject.getString("q_img_path"),
                                            objectSubject.getString("q_body"),
                                            objectSubject.getString("q_poster"),
                                            objectSubject.getString("q_poster_id"),
                                            objectSubject.getString("q_no_of_answers"),
                                            objectSubject.getString("q_top_ans_no_of_likes"),
                                            objectSubject.getString("q_top_ans_poster"),
                                            objectSubject.getString("q_top_ans_body")
                                    )
                                    questionsList!!.add(subjectBinder)
                                }


//                                questions_container_recycler.adapter = QuestionsAdapter(questionsList!!, this)
//                                ADAPTER.notifyDataSetChanged()
//                                ADAPTER.updateItems(questionsList!!)




                            }else{
//                                no_question_div?.visibility = View.VISIBLE
                            }
                        } else {
                            Toast.makeText(this, "An error occurred while loading the subjects", Toast.LENGTH_LONG).show()
                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError ->
//                    question_loading_img?.visibility = View.GONE
//                    if(volleyError.message == ""){
//                        ClassAlertDialog(this).alertMessage("Network connection failure. Check your internet connection and try again.")
//                    }else{
                    Toast.makeText(this, "Error in network connection. Swipe down to reload...", Toast.LENGTH_LONG).show()
//                    }
//                    ClassAlertDialog(this).alertMessage("Network connection failure. Check your internet connection and try again.")
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params.put("request_type", "get_questions")
                return params
            }
        }
        VolleySingleton.instance?.addToRequestQueue(stringRequest)//adding request to queue
        //volley interactions end

    }
}
