package com.jambpostutmeaskme


import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.support.v4.app.DialogFragment
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat
import android.support.v4.content.FileProvider
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.bumptech.glide.Glide
import com.google.android.gms.vision.Frame
import com.google.android.gms.vision.text.TextRecognizer
import kotlinx.android.synthetic.main.alert_dialog_inflate_choose_gallery.view.*
import kotlinx.android.synthetic.main.alert_dialog_inflate_preview_image.view.*
import kotlinx.android.synthetic.main.alert_dialog_inflate_preview_question.view.*
import kotlinx.android.synthetic.main.alert_dialog_inflate_sure_to_scan.view.*
import kotlinx.android.synthetic.main.fragment_dialog.*
import okhttp3.MediaType
import okhttp3.RequestBody
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.logging.Logger


class FragmentDialog : DialogFragment() {
    private var listener: FragmentIndexInteractionListener? = null
    lateinit var thisContext: Context

    private var fileUri: Uri? = null
    private var mediaPath: String? = null
    private var mImageFileLocation = ""
    private var postPath: String? = null
    lateinit var sqLiteDBHelper : SQLiteDBHelper
    var selectedSubjectName: String = "-1"
    var selectedSubjectId: String = "-1"
    var selectedTopicName: String = "-1"
    var selectedTopicId: String = "-1"
    var selectedExamTypeName: String = "-1"
    var selectedExamTypeId: Int = -1
    var selectedSchoolName: String = "-1"
    var selectedSchoolId: Int = -1
    var loadWithGlide: Boolean = false
    lateinit var previewDialog:AlertDialog

    lateinit var MESSAGE_BODY:String
    lateinit var OPTION_A:String
    lateinit var OPTION_B:String
    lateinit var OPTION_C:String
    lateinit var OPTION_D:String



    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_dialog, container, false)

    }
    fun initializeInputs(){
        MESSAGE_BODY = ClassHtmlFormater().formatTags(sanitizeInput(messageBody))
        OPTION_A = ClassHtmlFormater().formatTags(sanitizeInput(option_a))
        OPTION_B = ClassHtmlFormater().formatTags(sanitizeInput(option_b))
        OPTION_C = ClassHtmlFormater().formatTags(sanitizeInput(option_c))
        OPTION_D = ClassHtmlFormater().formatTags(sanitizeInput(option_d))
    }
    private fun sanitizeInput(input:EditText):String{
        return input.text.trim().toString()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        thisContext = activity!!.applicationContext
        thisContext = activity!!
        sqLiteDBHelper  = SQLiteDBHelper(thisContext)
        initializeInputs()

        content.setOnClickListener {
            listener!!.onCloseDialog("close")
        }

        pickImage.setOnClickListener {
            imagePickerDialog()
        }
        //
        imagePreviewWrapper.setOnClickListener {
            showImageDialog()
        }
        previewQuestion.setOnClickListener {
            initializeInputs()

//            if(!com.jambpostutmeaskme.ClassNetworkStatus(thisContext).isNetworkAvailable()){
//
//                Snackbar.make(it, "No Connection", Snackbar.LENGTH_LONG).setAction("Action", null).show()
//
//            }else {
                //checking for the inputs
                paramChecks()
//            }
        }
        saveQuestionAsDraft.setOnClickListener {
            val insert = sqLiteDBHelper.insertDrafts(
                    DraftList(
                            "",
                            selectedSubjectId,
                            selectedTopicId,
                            messageBody.text.trim().toString(),
                            postPath,
                            option_a.text.trim().toString(),
                            option_b.text.trim().toString(),
                            option_c.text.trim().toString(),
                            option_d.text.trim().toString(),
                            selectedSchoolId.toString(),
                            selectedExamTypeId.toString()
                    )
            )
            if(insert){
                Toast.makeText(thisContext, "Question Saved as draft!", Toast.LENGTH_LONG).show()
            }
        }
        initializeData()

    }
    private fun showScanDialog(){
        hideKeyboard()

        val inflater = LayoutInflater.from(context).inflate(R.layout.alert_dialog_inflate_sure_to_scan, null)
        val builder = AlertDialog.Builder(thisContext)

        builder.setView(inflater)
        val dialog = builder.create()
        dialog.show()
        inflater.scanTextBtn.setOnClickListener {
            scanTextFromImage()
            if (inflater.discardImageAfterScanCheckBox.isChecked){
                removeImage()
            }
            dialog.dismiss()
        }
    }
    private fun scanTextFromImage(){
        val progressDialog = ClassProgressDialog(thisContext,"Scanning, please wait...")
        progressDialog.createDialog()
//        val bitmap: Bitmap = BitmapFactory.decodeResource(this.resources, R.drawable.ocr_sample)
        val bitmap = BitmapFactory.decodeFile(postPath)

        val txtRecognizer = TextRecognizer.Builder(thisContext).build()
        if (!txtRecognizer.isOperational){
            // Shows if your Google Play services is not up to date or OCR is not supported for the device
            Toast.makeText(thisContext, "Detector dependencies are not yet available, wait for a while", Toast.LENGTH_SHORT).show()

        }else{
            // Set the bitmap taken to the frame to perform OCR Operations.
            val frame = Frame.Builder().setBitmap(bitmap).build()
            val items = txtRecognizer.detect(frame)

            messageBody.post {
                val stringBuilder = StringBuilder()
                for (i in 0 until items.size()) {
                    val item = items.valueAt(i)
                    stringBuilder.append(item.value)
                    stringBuilder.append("\n")

                }
                applyIntelligent(ClassHtmlFormater().replaceTags(stringBuilder.toString()))
//                val final = applyIntelligent(ClassHtmlFormater().replaceTags(stringBuilder.toString()))
//
//                messageBody.setText(stringBuilder.toString())
            }
            progressDialog.dismissDialog()//HIDING THE PROGRESS DIALOG
//            val strBuilder = StringBuilder()
//            for (i in 0 until items.size()){
//                val item = items.valueAt(i) as TextBlock
//                strBuilder.append(item.value)
//                strBuilder.append("/")
//            }
////                applyIntelligent(stringBuilder.toString())
//            applyIntelligent(ClassHtmlFormater().replaceTags(strBuilder.toString()))

        }
    }
    private fun applyIntelligent(value:String){
        var aDot = ""
        var bDot = ""
        var cDot = ""
        var dDot = ""
        when {
            value.contains("A.") -> {
                aDot = "A."
                bDot = "B."
                cDot = "C."
                dDot = "D."
            }
            value.contains("(A)") -> {
                aDot = "(A)"
                bDot = "(B)"
                cDot = "(C)"
                dDot = "(D)"
            }
            else -> {
                messageBody.setText(value)
                return
            }
        }
        var consts = ""
        val aValArr = value.split("$aDot")
        var aValue = value.split(aDot).last()
        var bValue = value.split(bDot).last()
        var cValue = value.split(cDot).last()
        var dValue = value.split(dDot).last()

        aValue = aValue.replace(bValue,"").trim()//remove from opt b and above
        aValue = aValue.replace(bDot,"").trim()//remove B.
        bValue = bValue.replace(cValue,"").trim()//remove opt c and above
        bValue = bValue.replace(cDot,"").trim()//remove C.
        cValue = cValue.replace(dValue,"").trim()
        cValue = cValue.replace(dDot,"").trim()

        var qBody = aValArr[aValArr.size-2]
//        var qBody = value.replace(aValue,"")
//        qBody = value.replace("A. "+aValue,"")
        val checkConst = dValue.contains("(")//constant exists
        val checkConst2 = dValue.contains("[")//constant exists
        val checkConst3 = dValue.contains("{")//constant exists
        when {
            checkConst -> {
                val dValArr = dValue.split("(")
                dValue = dValArr.first().trim()
                consts = dValArr[1]
                qBody = "$qBody \n<b>($consts</b>"
            }
            checkConst2 -> {
                val dValArr = dValue.split("[")
                dValue = dValArr.first().trim()
                consts = dValArr[1]
                qBody = "$qBody  \n<b>[$consts</b>"
            }
            checkConst3 -> {
                val dValArr = dValue.split("{")
                dValue = dValArr.first().trim()
                consts = dValArr[1]
                qBody = "$qBody  \n<b>{$consts</b>"
            }
            //remove from opt b and above
            //remove opt c and above
        }
        option_a.setText((aValue))
        option_b.setText((bValue))
        option_c.setText((cValue))
        option_d.setText((dValue))
        messageBody.setText(qBody)
    }
    private fun checkSup(vals :String):String{
        var newVal = ""
        val valArr = vals.split("10-")
        if (valArr.size>1){
            if (valArr.size >= 2)
                newVal = valArr[0]+"10<sup>-${valArr[1]}</sup>"
            else
                newVal = "10<sup>-${valArr[1]}</sup>"
        }else{
            newVal = vals
        }
        return newVal
    }
    private fun showImageDialog(){
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        val inflater = LayoutInflater.from(context).inflate(R.layout.alert_dialog_inflate_preview_image, null)
        val builder = AlertDialog.Builder(thisContext)

        if(postPath!=null){
            Glide.with(this).load(postPath).into(inflater.dialogPreviewImage)
//            if (loadWithGlide){
//                Glide.with(this).load(postPath).into(inflater.dialogPreviewImage)
//            }else{
//                val options = BitmapFactory.Options()//additional parameter
//                options.inSampleSize = 2//additional parameter
//                imagePreview.setImageBitmap(BitmapFactory.decodeFile(postPath,options))
//            }
        }

        builder.setView(inflater)
        builder.setPositiveButton("Crop"
        ) { _, _ ->
            //actions
            ClassSharePreference(context).setQImgUrl(postPath!!)
            listener?.onGotoCropActivity("")
        }
        builder.setNegativeButton("Scan Text"
        ) { _, _ ->
            //actions
            showScanDialog()
        }
        builder.setNeutralButton("Remove"
        ) { _, _ ->
            //actions
            removeImage()
        }

        val alertDialog = builder.create()
        alertDialog.show()

    }
    fun previewQuestion(){
        hideKeyboard()

        val inflater = LayoutInflater.from(context).inflate(R.layout.alert_dialog_inflate_preview_question, null)
        val builder = AlertDialog.Builder(thisContext)
        builder.setView(inflater)
        previewDialog = builder.create()
        previewDialog.show()

        inflater.previewSubject.text =      selectedSubjectName
        inflater.previewTopic.text   =      if(selectedTopicId != "-1"){ selectedTopicName
                                            }else{"No Topic Selected..."}
        inflater.previewQuestionSource.text =if(selectedSchoolId ==-1){ selectedExamTypeName
                                            }else{"$selectedExamTypeName - $selectedSchoolName"}
        inflater.previewMsgBody.text =      ClassHtmlFormater().fromHtml(MESSAGE_BODY)
        inflater.previewOptionA.text =      ClassHtmlFormater().fromHtml("A. $OPTION_A")
        inflater.previewOptionB.text =      ClassHtmlFormater().fromHtml("B. $OPTION_B")
        inflater.previewOptionC.text =      ClassHtmlFormater().fromHtml("C. $OPTION_C")
        inflater.previewOptionD.text =      ClassHtmlFormater().fromHtml("D. $OPTION_D")


        if(postPath!=null){
            Glide.with(this).load(postPath).into(inflater.previewImage)
        }
        inflater.publishQuestion.setOnClickListener {
            previewDialog.dismiss()
            uploadFile()
        }
    }
    private fun initializeData(){
        subjectSpinnerInitialize()
        topicSpinnerInitialize(-1)
        questionSourceInitialize()
        schoolInitialize()
    }
    private fun subjectSpinnerInitialize(){
        val subjectList = sqLiteDBHelper.getSubjects()
        val subjectsNameArray = arrayListOf<String>()
        val subjectIdArray = arrayListOf<String>()

        subjectsNameArray.add("Pick a Subject...")
        subjectIdArray.add("-1")
        for (element in subjectList) {
            subjectsNameArray.add(element.subject_name!!)
            subjectIdArray.add(element.subject_id!!)
        }
        val subjectSpinnerArrayAdapter = ArrayAdapter<String>(thisContext, android.R.layout.simple_spinner_dropdown_item, subjectsNameArray)
        //selected item will look like a spinner set from XML
        subjectSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        subject_spin.adapter = subjectSpinnerArrayAdapter

        subject_spin?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedSubjectId = subjectIdArray[position]
                selectedSubjectName = subjectsNameArray[position]
                topicSpinnerInitialize(selectedSubjectId.toInt())
            }

        }
    }
    fun topicSpinnerInitialize(subject_id:Int){
        val topicList = sqLiteDBHelper.getTopics(subject_id)
        val topicNameArray = arrayListOf<String>()
        val topicIdArray = arrayListOf<String>()

        topicNameArray.add("Select Topic...")
        topicIdArray.add("-1")
        topicNameArray.add("All")
        topicIdArray.add("-1")
        for (element in topicList) {
            topicNameArray.add(element.topic_name!!)
            topicIdArray.add(element.topic_id!!)
        }
        val topicSpinnerArrayAdapter = ArrayAdapter<String>(thisContext, android.R.layout.simple_spinner_dropdown_item, topicNameArray)
        //selected item will look like a spinner set from XML
        topicSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        topic_spin.adapter = topicSpinnerArrayAdapter

        topic_spin?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedTopicId = topicIdArray[position]
                selectedTopicName = topicNameArray[position]
//                showError(selectedTopicId+" - "+topicNameArray[position])
            }

        }
    }
    private fun questionSourceInitialize(){
        val qSourceArray = arrayListOf<String>("Source...","JAMB","POST UTME/SCREENING","WAEC","NECO","NABTEB","Others...")//Source or Type(Exam type)
        val qSourceIdArray = arrayListOf<Int>(-1,1,2,3,4,5,6)


        val question_source_spinSpinnerArrayAdapter = ArrayAdapter<String>(thisContext, android.R.layout.simple_spinner_dropdown_item, qSourceArray)
        //selected item will look like a spinner set from XML
        question_source_spinSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        question_source_spin.adapter = question_source_spinSpinnerArrayAdapter

        question_source_spin?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedExamTypeId = qSourceIdArray[position]
                selectedExamTypeName = qSourceArray[position]
//                showError("$selectedExamTypeId - "+qSourceArray[position])
                if(selectedExamTypeId == 2){
                    school.visibility = View.VISIBLE
                }else{
                    school.visibility = View.GONE
                    selectedSchoolId = -1
                    selectedSchoolName = ""
                }
            }

        }
    }
    private fun schoolInitialize(){
        val schoolList = sqLiteDBHelper.getSchools()
        val customerAdapter = SchoolListAdapter(
                thisContext,
                R.layout.adapter_design_inflate_school_list,
                schoolList
        )
        customerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        school.setAdapter(customerAdapter)
        school.showDropDown()
        school.threshold = 1
        school.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val det = schoolList[position]
            selectedSchoolId = det.school_id!!.toInt()
            selectedSchoolName = det.school_name+"("+det.school_code!!.toUpperCase()+")"
            Toast.makeText(thisContext, "${det.school_id} - ${det.school_name}", Toast.LENGTH_LONG).show()
        }



//        val schoolNameArray = arrayListOf<String>()
//        val schoolIdArray = arrayListOf<String>()
//
//        for (element in schoolList) {
//            schoolNameArray.add(element.school_name!!+", "+element.school_code!!.toLowerCase()+" ")
//            schoolIdArray.add(element.school_id!!)
//        }
//        val schoolSpinnerArrayAdapter = ArrayAdapter(thisContext, android.R.layout.simple_list_item_1, schoolNameArray)
//        //selected item will look like a spinner set from XML
//        schoolSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//        school.setAdapter(schoolSpinnerArrayAdapter)
//        school.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
//            override fun onNothingSelected(parent: AdapterView<*>?) {
//
//            }
//            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
//                selectedSchoolId = schoolIdArray[position].toInt()
//                selectedSchoolName = schoolNameArray[position]
//                val det = itemList[position]
//
//                Toast.makeText(thisContext, "${det.type} - ${det.name}", Toast.LENGTH_LONG).show()
//            }
//
//        }

    }
    private fun paramChecks(){
        //checking for the inputs
        if (selectedSubjectId =="-1"){
            showError("Please, Pick a Subject")
        }else if(selectedExamTypeId ==-1){
            showError("Choose Question Source")
        }else if(selectedExamTypeId ==2 && selectedSchoolId == -1){
            showError("Enter the School the question is gotten from")
        }else if ((MESSAGE_BODY =="")&&(postPath == null || postPath == "")){
            showError("Enter your Question...")
        }else if(OPTION_A==""||OPTION_B==""||OPTION_C==""||OPTION_D==""){
            showError("Fill all the Options")
        }else{
            hideError()
            previewQuestion()
        }

    }
    private fun showError(errMsg:String){
        errMsgContainer.visibility = View.VISIBLE
        qErrMsg.text = errMsg
        Toast.makeText(thisContext, errMsg, Toast.LENGTH_SHORT).show()
    }
    private fun hideError(){
        errMsgContainer.visibility = View.GONE
    }
    fun hideKeyboard(){
        val view = dialog.currentFocus
        if(view != null){
            val inputManager = thisContext.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputManager.hideSoftInputFromWindow(view.windowToken,InputMethodManager.HIDE_NOT_ALWAYS)
        }
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
    }
    private fun imagePickerDialog(){
        hideKeyboard()

        val inflater = LayoutInflater.from(context).inflate(R.layout.alert_dialog_inflate_choose_gallery, null)
        val builder = AlertDialog.Builder(activity!!)
        builder.setView(inflater)
        val dialogImgPicker = builder.create()
        dialogImgPicker.window!!.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT )
//        dialogImgPicker.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialogImgPicker.requestWindowFeature(Window.FEATURE_NO_TITLE)
        // This is line that does all the magic
        dialogImgPicker.window!!.setBackgroundDrawableResource(R.drawable.dialog_round_bg);
        dialogImgPicker.show()


        //select from gallery
        inflater.fromGallery.setOnClickListener {
            dialogImgPicker.dismiss()
            val galleryIntent = Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(galleryIntent, REQUEST_PICK_PHOTO)
        }
        //select from capture
        inflater.fromCapture.setOnClickListener {
            dialogImgPicker.dismiss()
            // start the image capture Intent
            if (Build.VERSION.SDK_INT >= 23 && ActivityCompat.checkSelfPermission(thisContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity!!, arrayOf(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 0)
            } else {
                captureImage()
            }

        }
        //remove image
        inflater.removeImage.setOnClickListener {
            //                                    imageView.setImageResource(R.drawable.ic_launcher_background);
            dialogImgPicker.dismiss()
            removeImage()

        }

    }

    override fun onResume() {
        super.onResume()
        if(ClassSharePreference(thisContext).getQImgUrl() !="") {
            postPath = ClassSharePreference(thisContext).getQImgUrl()
            Glide.with(this).load(postPath).into(imagePreview)

            //for scanning text
            if (ClassSharePreference(thisContext).getScanCheck() !=""){
                val scanCheck = ClassSharePreference(thisContext).getScanCheck()


//            Handler().postDelayed({
                scanTextFromImage()
//            }, 1000) // 1 second delay (takes millis)}
                if (scanCheck =="discard"){
                    removeImage()
                }
                ClassSharePreference(thisContext).setScanCheck("")
            }
        }else{
            removeImage()
        }
    }
    fun removeImage(){
        imagePreview.setImageDrawable(null)
        imagePreviewWrapper.visibility = View.GONE
        postPath = null
        ClassSharePreference(thisContext).setQImgUrl("")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            imagePreviewWrapper.visibility = View.VISIBLE

            if (requestCode == REQUEST_TAKE_PHOTO || requestCode == REQUEST_PICK_PHOTO) {
                if (data != null) {
                    // Get the Image from data
                    val selectedImage = data.data
                    val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)

                    val cursor = activity!!.contentResolver.query(selectedImage!!, filePathColumn, null, null, null)!!
                    cursor.moveToFirst()

                    val columnIndex = cursor.getColumnIndex(filePathColumn[0])
                    mediaPath = cursor.getString(columnIndex)
                    // Set the Image in ImageView for Previewing the Media
                    val options = BitmapFactory.Options()//additional parameter
                    options.inSampleSize = 2//additional parameter

                    imagePreview.setImageBitmap(BitmapFactory.decodeFile(mediaPath,options))
                    cursor.close()


                    loadWithGlide = false
                    postPath = mediaPath
                }


            } else if (requestCode == CAMERA_PIC_REQUEST) {
                if (Build.VERSION.SDK_INT <= 21) {
                    Glide.with(this).load(fileUri).into(imagePreview)
                    postPath = fileUri!!.path

                } else {

                    Glide.with(this).load(mImageFileLocation).into(imagePreview)
                    postPath = mImageFileLocation

                }

                loadWithGlide = true
            }

            ClassSharePreference(thisContext).setQImgUrl(postPath!!)
            listener?.onGotoCropActivity("")

        } else if (resultCode != Activity.RESULT_CANCELED) {
            Toast.makeText(thisContext, "Sorry, there was an error!", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (requestCode == 0) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                captureImage()
            }else{
                ClassAlertDialog(thisContext).alertMessage("You must allow camera permission in order to take a picture")
            }
        }
    }
    /**
     * Launching camera app to capture image
     */
    private fun captureImage() {
        if (Build.VERSION.SDK_INT > 21) { //use this if Lollipop_Mr1 (API 22) or above
            val callCameraApplicationIntent = Intent()
            callCameraApplicationIntent.action = MediaStore.ACTION_IMAGE_CAPTURE

            // We give some instruction to the intent to save the image
            var photoFile: File? = null

            try {
                // If the createImageFile will be successful, the photo file will have the address of the file
                photoFile = createImageFile()
                // Here we call the function that will try to catch the exception made by the throw function
            } catch (e: IOException) {
                Logger.getAnonymousLogger().info("Exception error in generating the file")
                e.printStackTrace()
            }

            // Here we add an extra file to the intent to put the address on to. For this purpose we use the FileProvider, declared in the AndroidManifest.
            val outputUri = FileProvider.getUriForFile(
                    thisContext,
                    BuildConfig.APPLICATION_ID + ".provider",
                    photoFile!!)
            callCameraApplicationIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri)

            // The following is a new line with a trying attempt
            callCameraApplicationIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)

            Logger.getAnonymousLogger().info("Calling the camera App by intent")

            // The following strings calls the camera app and wait for his file in return.
            startActivityForResult(callCameraApplicationIntent, CAMERA_PIC_REQUEST)
        } else {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

            fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE)

            intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri)

            startActivityForResult(intent, CAMERA_PIC_REQUEST)
        }


    }

    @Throws(IOException::class)
    internal fun createImageFile(): File {
        Logger.getAnonymousLogger().info("Generating the image - method started")

        // Here we create a "non-collision file name", alternatively said, "an unique filename" using the "timeStamp" functionality
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmSS", Locale.getDefault()).format(Date())
        val imageFileName = "IMAGE_" + timeStamp
        // Here we specify the environment location and the exact path where we want to save the so-created file
        val storageDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES + "/photo_saving_app")
        Logger.getAnonymousLogger().info("Storage directory set")

        // Then we create the storage directory if does not exists
        if (!storageDirectory.exists()) storageDirectory.mkdir()

        // Here we create the file using a prefix, a suffix and a directory
        val image = File(storageDirectory, "$imageFileName.jpg")
        // File image = File.createTempFile(imageFileName, ".jpg", storageDirectory);

        // Here the location is saved into the string mImageFileLocation
        Logger.getAnonymousLogger().info("File name and path set")

        mImageFileLocation = image.absolutePath
        // fileUri = Uri.parse(mImageFileLocation);
        // The file is returned to the previous intent across the camera application
        return image
    }


    /**
     * Here we store the file url as it will be null after returning from camera
     * app
     */
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        // save file url in bundle as it will be null on screen orientation
        // changes
        outState.putParcelable("file_uri", fileUri)
    }

    private fun getOutputMediaFileUri(type: Int): Uri {
        return Uri.fromFile(getOutputMediaFile(type))
    }

    // Uploading Image/Video
    private fun uploadFile() {
        if (postPath == null || postPath == "") {

            uploadTextQuestion()
        } else {
            val dialog = ClassProgressDialog(thisContext, "Submitting Question...")
            dialog.createDialog()

            // Map is used to multipart the file using okhttp3.RequestBody
            val map = HashMap<String, RequestBody>()
            val file = File(postPath!!)

            // Parsing any Media type file
            val requestBody = RequestBody.create(MediaType.parse("*/*"), file)
            map.put("file\"; filename=\"" + file.name + "\"", requestBody)

            val getResponse = com.jambpostutmeaskme.networking.AppConfig.getRetrofit().create(com.jambpostutmeaskme.networking.ApiConfig::class.java)
            val call = getResponse.upload(
                    "token",
                    map,
                    "add_questions",
                    MESSAGE_BODY,
                    OPTION_A,
                    OPTION_B,
                    OPTION_C,
                    OPTION_D,
                    selectedSubjectId,
                    selectedTopicId,
                    "",
                    "objective",
                    selectedExamTypeId.toString(),
                    selectedSchoolId.toString(),
                    ClassSharePreference(thisContext).getUserDetails("id")
            )

            call.enqueue(object : Callback<com.jambpostutmeaskme.networking.ServerResponse> {
                override fun onResponse(call: Call<com.jambpostutmeaskme.networking.ServerResponse>, response: Response<com.jambpostutmeaskme.networking.ServerResponse>) {

                    if (response.isSuccessful) {
                        if (response.body() != null) {
                            dialog.dismissDialog()

                            val serverResponse = response.body()

                            if (!serverResponse!!.success){
                                showError("${serverResponse.message}")
                            }else{
                                Toast.makeText(thisContext, "Question Submitted...", Toast.LENGTH_SHORT).show()

                                resetInputs()
                            }
                        }
                    } else {
                        dialog.dismissDialog()
                        showError("Error uploading image")
                    }
                }

                override fun onFailure(call: Call<com.jambpostutmeaskme.networking.ServerResponse>, t: Throwable) {

                    Log.v("Response gotten is", t.message)
                }
            })
        }

    }
    private fun uploadTextQuestion() {
        val dialog = ClassProgressDialog(context)
        dialog.createDialog()

        val stringRequest = object : StringRequest(Request.Method.POST, UrlHolder.URL_ADD_QUESTION,
                com.android.volley.Response.Listener<String> { response ->
                    dialog.dismissDialog()

                    try {
                        val obj = JSONObject(response)
                        val questionStatus = obj.getString("message")
                        if (questionStatus =="ok") {
                            Toast.makeText(thisContext, "Question Submitted...", Toast.LENGTH_LONG).show()

                            resetInputs()
                        }else{
                            showError(questionStatus)
                            Toast.makeText(thisContext, "$questionStatus", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                    previewDialog.hide()
                },
                com.android.volley.Response.ErrorListener { volleyError ->
                    dialog.dismissDialog()
                    Toast.makeText(thisContext, volleyError.message, Toast.LENGTH_LONG).show()
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params.put("request_type", "add_questions")
                params.put("message_body", MESSAGE_BODY)
                params.put("option_a", OPTION_A)
                params.put("option_b", OPTION_B)
                params.put("option_c", OPTION_C)
                params.put("option_d", OPTION_D)
                params.put("subject_id", selectedSubjectId)
                params.put("topic_id", selectedTopicId)
                params.put("question_type", "objective")
                params.put("exam_type", selectedExamTypeId.toString())
                params.put("school_id", selectedSchoolId.toString())
                params.put("poster_id", ClassSharePreference(thisContext).getUserDetails("id"))
                return params
            }
        }
        //adding request to queue
        VolleySingleton.instance?.addToRequestQueue(stringRequest)
        //volley interactions end
    }
    fun resetInputs(){
        messageBody?.setText("")
        option_a?.setText("")
        option_b?.setText("")
        option_c?.setText("")
        option_d?.setText("")
        hideError()
        removeImage()

        redirectActivity()
    }

    fun redirectActivity(){
        listener!!.onRedirect()
    }






    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // get the file url
        fileUri = savedInstanceState?.getParcelable("file_uri")
//        dialog.window!!.attributes.windowAnimations = R.style.Animation_WindowSlideUpDown
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setStyle(DialogFragment.STYLE_NORMAL, R.style.Animation_WindowSlideUpDown)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setStyle(STYLE_NO_TITLE, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen)
        } else {
            setStyle(STYLE_NO_TITLE, android.R.style.Theme_DeviceDefault_Light_NoActionBar)
        }

//        val d = dialog
//        if (d != null) {
//            val width = ViewGroup.LayoutParams.MATCH_PARENT
//            val height = ViewGroup.LayoutParams.MATCH_PARENT
//            d.window!!.setLayout(width, height)
//            d.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        }

    }
//
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.attributes.windowAnimations = R.style.Animation_WindowSlideUpDown
//        isCancelable = false
        return dialog
    }


    //Fragment communication with the Home Activity Starts
    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is FragmentIndexInteractionListener) {
            listener = context
        } else {
            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    interface FragmentIndexInteractionListener {
        fun onCloseDialog(input: String)
        fun onRedirect()
        fun onGotoCropActivity(input: String)
    }
    //Fragment communication with the Home Activity Stops




    companion object {
        private const val REQUEST_TAKE_PHOTO = 0
        private const val REQUEST_PICK_PHOTO = 2
        private const val CAMERA_PIC_REQUEST = 1111

        private val TAG = com.jambpostutmeaskme.FragmentDialog::class.java.simpleName

        private const val CAMERA_CAPTURE_IMAGE_REQUEST_CODE = 100

        const val MEDIA_TYPE_IMAGE = 1
        const val IMAGE_DIRECTORY_NAME = "Android File Upload"

        /**
         * returning image / video
         */
        private fun getOutputMediaFile(type: Int): File? {

            // External sdcard location
            val mediaStorageDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    IMAGE_DIRECTORY_NAME)

            // Create the storage directory if it does not exist
            if (!mediaStorageDir.exists()) {
                if (!mediaStorageDir.mkdirs()) {
                    Log.d(TAG, "Oops! Failed create "
                            + IMAGE_DIRECTORY_NAME + " directory")
                    return null
                }
            }

            // Create a media file name
            //val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val mediaFile: File
            if (type == MEDIA_TYPE_IMAGE) {
                mediaFile = File(mediaStorageDir.path + File.separator
                        + "IMG_" + ".jpg")
            } else {
                return null
            }

            return mediaFile
        }
    }
}
