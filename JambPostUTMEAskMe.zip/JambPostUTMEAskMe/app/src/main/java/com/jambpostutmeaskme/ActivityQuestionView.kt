package com.jambpostutmeaskme

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.widget.NestedScrollView
import android.support.v7.app.AlertDialog
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_question_view.*
import kotlinx.android.synthetic.main.alert_dialog_inflate_filter_question.view.*
import kotlinx.android.synthetic.main.include_questions_layout.*
import org.json.JSONException
import org.json.JSONObject

class ActivityQuestionView : AppCompatActivity(),QuestionsAdapter.QuestionsAdapterCallbackInterface {
    private var questionsList = mutableListOf<QuestionDataClassBinder>()
    lateinit var thisContext: Context
    var start_page_from:String = "0"
    var isLoadingDataFromServer = false  //for checking when data fetching is going on
    val linearLayoutManager = LinearLayoutManager(this)
    lateinit var ADAPTER : QuestionsAdapter
    lateinit var sqLiteDBHelper : SQLiteDBHelper


//    var subjectId:String? = ""
    var posterId:String? = "-1"
    var answeredStatus:String? = "-1"


    var selectedSubjectName: String = "-1"
    var selectedSubjectId: String = "-1"
    var selectedTopicName: String = "-1"
    var selectedTopicId: String = "-1"
    var selectedExamTypeName: String = "-1"
    var selectedExamTypeId: String = "-1"
    var selectedSchoolName: String = "-1"
    var selectedSchoolId: String = "-1"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question_view)
        setSupportActionBar(toolbar)
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowHomeEnabled(true)
        thisContext = this
        sqLiteDBHelper  = SQLiteDBHelper(thisContext)


        val preference = ClassSharePreference(this)
        selectedSubjectId = preference.getCurrentSubjectId()!!
        selectedTopicId = preference.getCurrentTopicId()!!
        posterId        = preference.getPosterId()!!
        selectedSchoolId = preference.getSchoolId().toString()
        answeredStatus = preference.getAnsweredStatus()
        selectedExamTypeId = preference.getExamType()!!
        selectedSubjectName = preference.getCurrentSubjectName()!!
        selectedTopicName = preference.getCurrentTopicName()!!

        addTitle()
        loadQuestions()


        ADAPTER = QuestionsAdapter(questionsList,thisContext)
        recyclerview.layoutManager = linearLayoutManager
        recyclerview.itemAnimator = DefaultItemAnimator()
        recyclerview.adapter = ADAPTER

        nestedSV.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { v, scrollX, scrollY, oldScrollX, oldScrollY ->
            if ((scrollY == v.getChildAt(0).measuredHeight - v.measuredHeight)&&(scrollY>oldScrollY)) {
//            if ((scrollY >= v.getChildAt(v.childCount - 1).measuredHeight - v.measuredHeight)&&(scrollY>oldScrollY)) {
                if (!isLoadingDataFromServer){
                    isLoadingDataFromServer = true
                    loadQuestions(true)//loading questions again
                }
            }
        })
    }
    private fun addTitle(){
        toolbar.title = when {
            selectedSubjectId != "-1" -> selectedSubjectName
            selectedTopicId != "-1" -> selectedTopicName
            else -> "Questions"
        }
    }
    private fun showFilterDialog(){
        val inflater = LayoutInflater.from(thisContext).inflate(R.layout.alert_dialog_inflate_filter_question, null)
        val builder = AlertDialog.Builder(thisContext)
        builder.setView(inflater)
        val dialog = builder.create()
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        if (answeredStatus =="1"){
            inflater.filter_answered_check.isChecked = true//answered
        }else if (answeredStatus =="2")inflater.filter_unanswered_check.isChecked = true//unanswered


        //for checking answered
        inflater.filter_answered_check.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                inflater.filter_answered_check.isChecked = true
                inflater.filter_unanswered_check.isChecked = false
            } else {
                inflater.filter_answered_check.isChecked = false
                answeredStatus = "-1"
            }
        }
        //for checking unanswered
        inflater.filter_unanswered_check.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                inflater.filter_unanswered_check.isChecked = true
                inflater.filter_answered_check.isChecked = false
            } else {
                inflater.filter_unanswered_check.isChecked = false
                answeredStatus = "-1"
            }
        }
        //FILTER Q
        inflater.filterQuestion.setOnClickListener {
            ClassSharePreference(thisContext).reset()
            val filter_answered_check = inflater.filter_answered_check
            val filter_unanswered_check = inflater.filter_unanswered_check

            if (filter_answered_check.isChecked){answeredStatus = "1"}//answered
            if(filter_unanswered_check.isChecked) {answeredStatus = "2"}//unanswered

            dialog.dismiss()
            posterId = "-1"//to be removed later

            ClassSharePreference(thisContext).setCurrentSubjectId(selectedSubjectId)
            ClassSharePreference(thisContext).setCurrentTopicId(selectedTopicId)
            ClassSharePreference(thisContext).setPosterId(posterId!!)
            ClassSharePreference(thisContext).setSchoolId(selectedSchoolId.toInt())
            ClassSharePreference(thisContext).setExamType(selectedExamTypeId)
            ClassSharePreference(thisContext).setAnsweredStatus(answeredStatus.toString())
            refreshQ()
            addTitle()
        }
        //load subjects
        subjectSpinnerInitialize(inflater.filter_sub_spin,inflater.filter_topic_spin)
        //load topics
//        topicSpinnerInitialize(inflater.filter_topic_spin)
        //load exam type
        examTypeInitialize(inflater.filter_exam_type_spin,inflater.filter_school)

    }

    private fun refreshQ(){
        clearQuestionsList()
        ADAPTER.addItems(questionsList)
        ADAPTER.notifyDataSetChanged()
        loadQuestions()
    }
    private fun topicSpinnerInitialize(topicFilterView:Spinner, subject_id:Int = -1){
        val topicList = sqLiteDBHelper.getTopics(subject_id)
        val topicNameArray = arrayListOf<String>()
        val topicIdArray = arrayListOf<String>()

        //FOR GETTING SUBJECT NAME
        val subjectList = sqLiteDBHelper.getSubjects()
        val subjectsNameArray = arrayListOf<String>()
        val subjectsIdArray = arrayListOf<String>()
        for (element in subjectList) {
            subjectsNameArray.add(element.subject_name!!.toLowerCase())
            subjectsIdArray.add(element.subject_id!!.toLowerCase())
        }//GETTING SUBJECT NAME ENDS

        topicNameArray.add("Select a Topic...")
        topicIdArray.add("-1")
        topicNameArray.add("All")
        topicIdArray.add("-1")
        for (element in topicList) {
            val getSubId = subjectsIdArray.indexOf(element.topic_subject_id)
            val getSubName = subjectsNameArray[getSubId]
            if (subject_id == -1){
                topicNameArray.add(element.topic_name!!+" ($getSubName)")
            }else{
                topicNameArray.add(element.topic_name!!)
            }
            topicIdArray.add(element.topic_id!!)
        }
        val topicSpinnerArrayAdapter = ArrayAdapter<String>(thisContext, android.R.layout.simple_spinner_dropdown_item, topicNameArray)
        //selected item will look like a spinner set from XML
        topicSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        topicFilterView.adapter = topicSpinnerArrayAdapter

        topicFilterView.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedTopicId = ""
            }
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedTopicId = topicIdArray[position]

                selectedTopicId = topicIdArray[position]
                selectedTopicName = topicNameArray[position]
//                selectedFilterTopicName = topicNameArray[position]
            }
        }

        if(selectedTopicId != "-1"){
            val topicIdPos = topicIdArray.indexOf(selectedTopicId)
            topicFilterView.setSelection(topicIdPos)
        }
    }
    private fun schoolInitialize(schoolFilterView:Spinner){
        val schoolList = sqLiteDBHelper.getSchools()
        val schoolNameArray = arrayListOf<String>()
        val schoolIdArray = arrayListOf<String>()

        schoolNameArray.add("Institution")
        schoolIdArray.add("-1")
        schoolNameArray.add("All")
        schoolIdArray.add("-1")
        for (element in schoolList) {
            schoolNameArray.add(element.school_name!!+", "+element.school_code!!.toLowerCase()+" ")
            schoolIdArray.add(element.school_id!!)
        }
        val schoolSpinnerArrayAdapter = ArrayAdapter(thisContext, android.R.layout.simple_spinner_dropdown_item, schoolNameArray)
        //selected item will look like a spinner set from XML
        schoolSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        schoolFilterView.adapter = schoolSpinnerArrayAdapter

        schoolFilterView.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedSchoolId = schoolIdArray[position]
                selectedSchoolName = schoolNameArray[position]

            }

        }

        if(selectedSchoolId != "-1"){
            val schoolIdPos = schoolIdArray.indexOf(selectedSchoolId)
            schoolFilterView.setSelection(schoolIdPos)
        }


    }
    private fun subjectSpinnerInitialize(subjectFilterView:Spinner,topicFilterView:Spinner){
        val subjectList = sqLiteDBHelper.getSubjects()
        val subjectsNameArray = arrayListOf<String>()
        val subjectIdArray = arrayListOf<String>()

        subjectsNameArray.add("Pick a Subject...")
        subjectIdArray.add("-1")
        subjectsNameArray.add("All")
        subjectIdArray.add("-1")
        for (element in subjectList) {
            subjectsNameArray.add(element.subject_name!!)
            subjectIdArray.add(element.subject_id!!)
        }
        val subjectSpinnerArrayAdapter = ArrayAdapter<String>(thisContext, android.R.layout.simple_spinner_dropdown_item, subjectsNameArray)
        //selected item will look like a spinner set from XML
        subjectSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        subjectFilterView.adapter = subjectSpinnerArrayAdapter

        subjectFilterView.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedSubjectId = subjectIdArray[position]
                selectedSubjectName = subjectsNameArray[position]
                topicSpinnerInitialize(topicFilterView, selectedSubjectId.toInt())
            }

        }

        if(selectedSubjectId != "-1"){
            val subIdPos = subjectIdArray.indexOf(selectedSubjectId)
            subjectFilterView.setSelection(subIdPos)
        }
    }
    private fun examTypeInitialize(examTypeFilterView:Spinner, schoolFilterView:Spinner){
        val qSourceArray = arrayListOf<String>("Type...","All","JAMB","POST UTME/SCREENING","WAEC","NECO","NABTEB","Others...")//Source or Type(Exam type)
        val qSourceIdArray = arrayListOf<String>("-1","-1","1","2","3","4","5","6")


        val question_source_spinSpinnerArrayAdapter = ArrayAdapter<String>(thisContext, android.R.layout.simple_spinner_dropdown_item, qSourceArray)
        //selected item will look like a spinner set from XML
        question_source_spinSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        examTypeFilterView.adapter = question_source_spinSpinnerArrayAdapter

        examTypeFilterView.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedExamTypeId = qSourceIdArray[position]
                selectedExamTypeName = qSourceArray[position]
//                showError("$selectedExamTypeId - "+qSourceArray[position])
                if(selectedExamTypeId == "2"){
                    schoolFilterView.visibility = View.VISIBLE
                    schoolInitialize(schoolFilterView)

                }else{
                    schoolFilterView.visibility = View.GONE
                    selectedSchoolId = "-1"
                    selectedSchoolName = ""
                }
            }

        }

        if(selectedExamTypeId != "-1"){
            val examTypeIdPos = qSourceIdArray.indexOf(selectedExamTypeId)
            examTypeFilterView.setSelection(examTypeIdPos)

            if(selectedExamTypeId == "2"){
                schoolFilterView.visibility = View.VISIBLE
                schoolInitialize(schoolFilterView)
            }else{
                schoolFilterView.visibility = View.GONE
                selectedSchoolId = "-1"
                selectedSchoolName = ""
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_questions, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                super.onBackPressed()
            }
            R.id.menu_action_filter -> {
                showFilterDialog()
            }
            else -> return super.onOptionsItemSelected(item)
        }

        return true
    }

    override fun onReloadCallback() {
        finish()
        startActivity(intent)
    }
    private fun clearQuestionsList() {
        val size = questionsList.size
        if (size > 0) {
            for (i in 0 until size) {
                questionsList.removeAt(0)
            }
        }
    }
    private fun loadQuestions(isReloading:Boolean = false){
//        clearQuestionsList()
        start_page_from = if(questionsList.size==0){
            "0"
        }else{
            questionsList.last().question_id
        }

        //creating volley string request
        loadingProgressbar?.visibility = View.VISIBLE
        val stringRequest = object : StringRequest(Request.Method.POST, UrlHolder.URL_GET_QUESTIONS,
                Response.Listener<String> { sub ->
                    loadingProgressbar?.visibility = View.GONE
                    isLoadingDataFromServer = false

                    try {
                        val obj = JSONObject(sub)
                        if (!obj.getBoolean("error")) {
                            val noOfSub = obj.getJSONArray("topic_questionz_array")

                            if ((noOfSub.length()!=0)){
                                no_question_tag?.visibility = View.GONE

                                val q_data_array = mutableListOf<QuestionDataClassBinder>()
                                for (i in 0 until noOfSub.length()) {
                                    val objectSubject = noOfSub.getJSONObject(i)
                                    q_data_array.add(QuestionDataClassBinder(
                                            objectSubject.getString("question_id"),
                                            objectSubject.getString("subject_id"),
                                            objectSubject.getString("topic_id"),
                                            objectSubject.getString("subject_name"),
                                            objectSubject.getString("topic_name"),
                                            objectSubject.getString("question_sub_or_topic"),
                                            objectSubject.getString("question_type"),
                                            objectSubject.getString("q_posted_time"),
                                            objectSubject.getString("q_img_path"),
                                            objectSubject.getString("q_body"),
                                            objectSubject.getString("q_poster"),
                                            objectSubject.getString("q_poster_id"),
                                            objectSubject.getString("q_no_of_answers"),
                                            objectSubject.getString("q_top_ans_no_of_likes"),
                                            objectSubject.getString("q_top_ans_poster"),
                                            objectSubject.getString("q_top_ans_body")
                                    ))
                                }
                                ADAPTER.addItems(q_data_array)


                            }else if(!isReloading){
                                no_question_tag?.visibility = View.VISIBLE
                            }
                        } else {
                            Toast.makeText(this, "An error occurred while loading the subjects", Toast.LENGTH_LONG).show()
                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError ->
                    loadingProgressbar?.visibility = View.GONE
                    isLoadingDataFromServer = false

                    Toast.makeText(this, "Error in network connection. Swipe down to reload...", Toast.LENGTH_LONG).show()
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params.put("request_type", "get_questions")
                params.put("start_page_from", start_page_from)
                params.put("answered_status", answeredStatus)
                params.put("subject_id", selectedSubjectId)
                params.put("exam_type", selectedExamTypeId)
                params.put("topic_id", selectedTopicId)
                params.put("school_id", selectedSchoolId)
                params.put("poster_id", posterId)
                return params
            }
        }
        VolleySingleton.instance?.addToRequestQueue(stringRequest)//adding request to queue
        //volley interactions end

    }



    fun showProgress() {
        val f = FragmentProgressBar().getInstance()
        supportFragmentManager.beginTransaction().add(f, PROGRESS_DIALOG).commitAllowingStateLoss()
    }

    fun dismissProgress() {
//        if (!isResume()) return
        val manager = supportFragmentManager ?: return
        val f = manager.findFragmentByTag(PROGRESS_DIALOG) as FragmentProgressBar
        if (f != null) {
            supportFragmentManager.beginTransaction().remove(f).commitAllowingStateLoss()
        }
    }

    companion object {
        val PROGRESS_DIALOG = FragmentProgressBar::class.java.name
    }

}
