package com.jambpostutmeaskme

import android.content.Context
import android.graphics.*
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.Menu
import android.graphics.Bitmap.CompressFormat
import android.graphics.Bitmap
import android.widget.LinearLayout
import android.widget.EditText
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.os.Environment
import android.support.v7.app.AlertDialog
import android.view.MenuItem
import java.io.File
import java.io.FileOutputStream
import android.graphics.BlurMaskFilter
import android.graphics.MaskFilter
import android.media.ThumbnailUtils
import android.widget.ImageView
import android.widget.Toast
import java.io.ByteArrayOutputStream


class ActivitySketch : AppCompatActivity() {

//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_sketch)
//    }

//    var mv: DrawingView? = null
    var dialog: AlertDialog? = null
    var dv: DrawingView?=null
    lateinit var mPaint:Paint
    lateinit var mBlur:MaskFilter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        dv = DrawingView(this)
        dv!!.isDrawingCacheEnabled = true
        dv!!.setBackgroundResource(R.drawable.q_user)//set the back ground if you wish to
        setContentView(dv)

        mPaint = Paint()
        mPaint.isAntiAlias = true
        mPaint.isDither = true
        mPaint.color = Color.GREEN
        mPaint.style = Paint.Style.STROKE
        mPaint.strokeJoin = Paint.Join.ROUND
        mPaint.strokeCap = Paint.Cap.ROUND
        mPaint.strokeWidth = 12f

        mBlur = BlurMaskFilter(8f, BlurMaskFilter.Blur.NORMAL)
    }

    private val COLOR_MENU_ID = Menu.FIRST
    private val EMBOSS_MENU_ID = Menu.FIRST + 1
    private val BLUR_MENU_ID = Menu.FIRST + 2
    private val ERASE_MENU_ID = Menu.FIRST + 3
    private val SRCATOP_MENU_ID = Menu.FIRST + 4
    private val Save = Menu.FIRST + 5

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        super.onCreateOptionsMenu(menu)

        menu.add(0, COLOR_MENU_ID, 0, "Color").setShortcut('3', 'c')
        menu.add(0, BLUR_MENU_ID, 0, "Blur").setShortcut('5', 'z')
        menu.add(0, ERASE_MENU_ID, 0, "Erase").setShortcut('5', 'z')
        menu.add(0, SRCATOP_MENU_ID, 0, "SrcATop").setShortcut('5', 'z')
        menu.add(0, Save, 0, "Save").setShortcut('5', 'z')

        return true
    }


    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        super.onPrepareOptionsMenu(menu)
        return true
    }
    fun saveDrawing(){
        var whatTheUserDrewBitmap = dv!!.drawingCache
        // don't forget to clear it (see above) or you just get duplicates

        // almost always you will want to reduce res from the very high screen res
        whatTheUserDrewBitmap = ThumbnailUtils.extractThumbnail(whatTheUserDrewBitmap, 256, 256)
        // NOTE that's an incredibly useful trick for cropping/resizing squares
        // while handling all memory problems etc
        // http://stackoverflow.com/a/17733530/294884


        // these days you often need a "byte array". for example,
        // to save to parse.com or other cloud services
        val baos = ByteArrayOutputStream()
        whatTheUserDrewBitmap.compress(Bitmap.CompressFormat.PNG, 0, baos)
        val yourByteArray: ByteArray
        yourByteArray = baos.toByteArray()
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
    mPaint.xfermode = null
    mPaint.alpha = 0xFF

    when (item.itemId) {
        COLOR_MENU_ID -> {
            mPaint = Paint()
            mPaint.isAntiAlias = true
            mPaint.isDither = true
            mPaint.color = Color.BLACK
            mPaint.style = Paint.Style.STROKE
            mPaint.strokeJoin = Paint.Join.ROUND
            mPaint.strokeWidth = 6f
            return true
        }
        BLUR_MENU_ID -> {
            if (mPaint.maskFilter !== mBlur) {
                mPaint.maskFilter = mBlur
            } else {
                mPaint.maskFilter = null
            }
            return true
        }
        ERASE_MENU_ID -> {
            mPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            mPaint.alpha = 0x80
            mPaint.strokeWidth = 30f
            return true
        }
        SRCATOP_MENU_ID -> {

            mPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
            mPaint.alpha = 0x80
            return true
        }
        Save -> {
            val editalert = AlertDialog.Builder(this)
            editalert.setTitle("Please Enter the name with which you want to Save")
            val input = EditText(this)
            val image_view = ImageView(this)
            val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT)
            input.layoutParams = lp
//            image_view.layoutParams = lp
            editalert.setView(input)
//            editalert.setView(image_view)
            editalert.setPositiveButton("OK") { dialog, whichButton ->
                val name = input.text.toString()
                val bitmap = dv!!.drawingCache

                val path = Environment.getExternalStorageDirectory().absolutePath
//                val path = Environment.getExternalStorageDirectory().toString() + "/Japu/"

                val file = File("$path/$name.png")
                try {
                    if (!file.exists()) {
                        file.createNewFile()
//                        Toast.makeText(this, "created", Toast.LENGTH_LONG).show()
                    }
                    val ostream = FileOutputStream(file)
                    bitmap.compress(CompressFormat.PNG, 10, ostream)
                    ostream.close()
                    dv!!.invalidate()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                finally {
                    dv!!.isDrawingCacheEnabled = false
                }
            }

            editalert.show()
            return true
        }
    }
    return super.onOptionsItemSelected(item)
}
    inner class DrawingView(internal var context: Context) : View(context) {

        var widthsz: Int = 0
        var heightsz: Int = 0
        lateinit var mBitmap:Bitmap
        lateinit var mCanvas:Canvas
        private val mPath: Path
        private val mBitmapPaint: Paint
        private val circlePaint: Paint
        private val circlePath: Path

        private var mX: Float = 0.toFloat()
        private var mY: Float = 0.toFloat()

        init {
            mPath = Path()
            mBitmapPaint = Paint(Paint.DITHER_FLAG)
            circlePaint = Paint()
            circlePath = Path()
            circlePaint.isAntiAlias = true
            circlePaint.color = Color.BLUE
            circlePaint.style = Paint.Style.STROKE
            circlePaint.strokeJoin = Paint.Join.MITER
            circlePaint.strokeWidth = 4f
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)

            widthsz = w      // don't forget these
            heightsz = h

            mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            mCanvas = Canvas(mBitmap)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            canvas.drawBitmap(mBitmap, 0f, 0f, mBitmapPaint)
            canvas.drawPath(mPath, mPaint)
            canvas.drawPath(circlePath, circlePaint)
        }

        private fun touch_start(x: Float, y: Float) {
            mPath.reset()
            mPath.moveTo(x, y)
            mX = x
            mY = y
        }

        private fun touch_move(x: Float, y: Float) {
            val dx = Math.abs(x - mX)
            val dy = Math.abs(y - mY)
            if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
                mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2)
                mX = x
                mY = y

                circlePath.reset()
                circlePath.addCircle(mX, mY, 30f, Path.Direction.CW)
            }
        }

        private fun touch_up() {
            mPath.lineTo(mX, mY)
            circlePath.reset()
            // commit the path to our offscreen
            mCanvas.drawPath(mPath, mPaint)
            // kill this so we don't double draw
            mPath.reset()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val x = event.x
            val y = event.y

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    touch_start(x, y)
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    touch_move(x, y)
                    invalidate()
                }
                MotionEvent.ACTION_UP -> {
                    touch_up()
                    invalidate()
                }
            }
            return true
        }

    }

    companion object {
        private val TOUCH_TOLERANCE = 4f
    }
}
