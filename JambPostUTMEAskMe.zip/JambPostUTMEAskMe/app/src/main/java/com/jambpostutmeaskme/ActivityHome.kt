package com.jambpostutmeaskme

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import android.support.v4.widget.NestedScrollView
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.app_bar_activity_home.*
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.*
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import org.json.JSONException
import org.json.JSONObject
import kotlinx.android.synthetic.main.include_questions_layout.*


class ActivityHome : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener , FragmentDialog.FragmentIndexInteractionListener, QuestionsAdapter.QuestionsAdapterCallbackInterface {

    private var questionsList = mutableListOf<QuestionDataClassBinder>()
    lateinit var thisContext: Context
    var start_page_from:String = "0"
    var isLoadingDataFromServer = false  //for checking when data fetching is going on

    val linearLayoutManager = LinearLayoutManager(this)
    lateinit var ADAPTER : QuestionsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        setSupportActionBar(toolbar)
        thisContext = this
//        this.deleteDatabase("jambpostutmeask.db")//delete database
//        startActivity(Intent(this, ActivityQuestionSolutions::class.java))
//        ClassDownloadDataFromServer(this).downLoadSubjectsAndTopics()

        drawer_layout.setScrimColor(Color.TRANSPARENT)

        val actionBarDrawerToggle = object : ActionBarDrawerToggle(this, drawer_layout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            private val scaleFactor = 6f

            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                super.onDrawerSlide(drawerView, slideOffset)
                val slideX = drawerView.width * slideOffset
                content.translationX = slideX
//                content.scaleX = 1 - slideOffset / scaleFa ctor
//                content.scaleY = 1 - slideOffset / scaleFactor
            }
        }
        drawer_layout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        ask_question.setOnClickListener {
            dialogShow()

        }
        recentQuestions.setOnClickListener {
            startActivity(Intent(this, ActivityQuestionView::class.java))
        }

        nav_view.setNavigationItemSelectedListener(this)



        ADAPTER = QuestionsAdapter(questionsList,thisContext)
        recyclerview.layoutManager = linearLayoutManager
        recyclerview.itemAnimator = DefaultItemAnimator()
        recyclerview.adapter = ADAPTER
        loadQuestions()

        recyclerview.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                // only load more items if it's currently not loading
                if (!isLoadingDataFromServer) {
//                    if (loadingProgressbar?.visibility == View.VISIBLE) {
                    // only load more items if the last visible item on the screen is the last item
                    Log.d("endlessscroll", "last visible position: ${linearLayoutManager.findLastCompletelyVisibleItemPosition()}, total count: ${linearLayoutManager.itemCount}")
                    if (linearLayoutManager.findLastCompletelyVisibleItemPosition() >= linearLayoutManager.itemCount - 1 ) {

//                        isLoadingDataFromServer = true
//                        loadQuestions(true)//loading questions again

                    }
                    if(!recyclerView.canScrollVertically(1)){//1->bottom, -1 ->top
//
//                        questions_container_recycler.post {
//                            ADAPTER.addFooter()
//                        }
//                        loadQuestions(true)//loading questions again
                    }


                }
            }
        })
        nestedSV.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { v, scrollX, scrollY, oldScrollX, oldScrollY ->
            val TAG = "nested_sync"
            if (scrollY > oldScrollY) {
                Log.i(TAG, "Scroll DOWN")
            }
            if (scrollY < oldScrollY) {
                Log.i(TAG, "Scroll UP")
            }

            if (scrollY == 0) {
                Log.i(TAG, "TOP SCROLL")
            }

            if (scrollY == v.getChildAt(0).measuredHeight - v.measuredHeight) {
                Log.i(TAG, "BOTTOM SCROLL")
                if (!isLoadingDataFromServer)
                //check for scroll down
                {
                    isLoadingDataFromServer = true
                    loadQuestions(true)//loading questions again
                }
            }
        })


    }

    override fun onBackPressed() {
        if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
            drawer_layout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.activity_home, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        when (item.itemId) {
            R.id.action_settings -> return true
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        when (item.itemId) {
            R.id.nav_camera -> {
                // Handle the camera action
            }
            R.id.nav_gallery -> {

            }
            R.id.nav_slideshow -> {

            }
            R.id.nav_manage -> {

            }
            R.id.nav_share -> {

            }
            R.id.nav_send -> {

            }
        }

        drawer_layout.closeDrawer(GravityCompat.START)
        return true
    }

    override fun onReloadCallback() {
        startActivity(Intent(this, ActivityQuestionView::class.java))
    }
    private fun loadQuestions(isReloading:Boolean = false){
        start_page_from = if(questionsList.size==0){
            "0"
        }else{
            questionsList.last().question_id
        }

        //creating volley string request
        loadingProgressbar?.visibility = View.VISIBLE
        val stringRequest = object : StringRequest(Request.Method.POST, UrlHolder.URL_GET_QUESTIONS,
                Response.Listener<String> { sub ->
                    loadingProgressbar?.visibility = View.GONE
                    isLoadingDataFromServer = false

                    try {
                        val obj = JSONObject(sub)
                        if (!obj.getBoolean("error")) {
//                            questionsList!!.clear()
                            val noOfSub = obj.getJSONArray("topic_questionz_array")

                            if ((noOfSub.length()!=0)){
                                no_question_tag?.visibility = View.GONE

                                val q_data_array = mutableListOf<QuestionDataClassBinder>()
                                for (i in 0 until noOfSub.length()) {
                                    val objectSubject = noOfSub.getJSONObject(i)
                                    q_data_array.add(QuestionDataClassBinder(
                                            objectSubject.getString("question_id"),
                                            objectSubject.getString("subject_id"),
                                            objectSubject.getString("topic_id"),
                                            objectSubject.getString("subject_name"),
                                            objectSubject.getString("topic_name"),
                                            objectSubject.getString("question_sub_or_topic"),
                                            objectSubject.getString("question_type"),
                                            objectSubject.getString("q_posted_time"),
                                            objectSubject.getString("q_img_path"),
                                            objectSubject.getString("q_body"),
                                            objectSubject.getString("q_poster"),
                                            objectSubject.getString("q_poster_id"),
                                            objectSubject.getString("q_no_of_answers"),
                                            objectSubject.getString("q_top_ans_no_of_likes"),
                                            objectSubject.getString("q_top_ans_poster"),
                                            objectSubject.getString("q_top_ans_body")
                                    ))
                                }
//                                questionsList.add(q_data_array)

//                                itemArrayAdapter.addItems(newItems)

//                                ADAPTER.addItems(questionsList)
                                ADAPTER.addItems(q_data_array)


                            }else if(!isReloading){
                                no_question_tag?.visibility = View.VISIBLE
                            }
                        } else {
                            Toast.makeText(this, "An error occurred while loading the subjects", Toast.LENGTH_SHORT).show()
                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError ->
                    loadingProgressbar?.visibility = View.GONE
                    isLoadingDataFromServer = false

                    Toast.makeText(this, "Error in network connection. Swipe down to reload...", Toast.LENGTH_LONG).show()
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params.put("request_type", "get_questions")
                params.put("start_page_from", start_page_from)
                return params
            }
        }
        VolleySingleton.instance?.addToRequestQueue(stringRequest)//adding request to queue
        //volley interactions end

    }
    fun refreshQ(){
        clearQuestionsList()
        ADAPTER.addItems(questionsList)
        ADAPTER.notifyDataSetChanged()
        loadQuestions()
    }
    private fun clearQuestionsList() {
        val size = questionsList.size
        if (size > 0) {
            for (i in 0 until size) {
                questionsList.removeAt(0)
            }
        }
    }


    private val dialogFragment = FragmentDialog()
    private fun dialogShow(){
        val ft = supportFragmentManager.beginTransaction()
//        val prev = supportFragmentManager.findFragmentByTag("dialog")
        val prev = supportFragmentManager.findFragmentByTag(FragmentDialog::class.java.name)
        if (prev != null) {
            ft.remove(prev)
        }
        ft.addToBackStack(null)
//        val dialogFragment = FragmentDialog()
        dialogFragment.show(ft, FragmentDialog::class.java.name)
    }
    override fun onCloseDialog(input: String) {
        dialogFragment.dismiss()
    }

    override fun onRedirect() {
        dialogFragment.dismiss()
        refreshQ()
//        startActivity(Intent(this, ActivityTest::class.java))
    }
    override fun onGotoCropActivity(input: String) {
        startActivity(Intent(this, Main3Activity::class.java))
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left)
    }






}
