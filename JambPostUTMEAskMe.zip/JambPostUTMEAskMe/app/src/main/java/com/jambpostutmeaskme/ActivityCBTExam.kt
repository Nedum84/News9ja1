package com.jambpostutmeaskme

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_cbtexam.*
import org.json.JSONException
import org.json.JSONObject

class ActivityCBTExam : AppCompatActivity() {
    private var examQList = mutableListOf<ExamQDataClassBinder>()
    lateinit var ADAPTER : CBTQsAdapter
    var linearLayoutManager = GridLayoutManager(this, 2)
    lateinit var thisContext: Context
    var index = -1


    var selectedSubjectId = "1"
    var selectedExamTypeId = "1"
    var selectedTopicId = "1"
    var selectedSchoolId = "1"
    var examYear = "1"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cbtexam)
        thisContext = this
        linearLayoutManager = GridLayoutManager(thisContext, 2)



        ADAPTER = CBTQsAdapter(examQList,thisContext)
        cbt_qs_recyclerview.layoutManager = linearLayoutManager
        cbt_qs_recyclerview.itemAnimator = DefaultItemAnimator()
        cbt_qs_recyclerview.adapter = ADAPTER
        downloadQuestions()
    }
    private fun downloadQuestions(){

        //creating volley string request
        val stringRequest = object : StringRequest(Request.Method.POST, UrlHolder.URL_GET_QUESTIONS,
                Response.Listener<String> { sub ->

                    try {
                        val obj = JSONObject(sub)
                        if (!obj.getBoolean("error")) {
                            val noOfSub = obj.getJSONArray("cbt_exam_questionszs_arrzs")

                            if ((noOfSub.length()!=0)){

                                val dataArray = mutableListOf<ExamQDataClassBinder>()
                                for (i in 0 until noOfSub.length()) {
                                    val objectSubject = noOfSub.getJSONObject(i)

                                    dataArray.add(ExamQDataClassBinder(
                                            objectSubject.getString("question_id"),
                                            objectSubject.getString("subject_id"),
                                            objectSubject.getString("topic_id"),
                                            objectSubject.getString("question_type"),
                                            objectSubject.getString("q_img_path"),
                                            objectSubject.getString("q_body"),
                                            objectSubject.getString("option_a"),
                                            objectSubject.getString("option_b"),
                                            objectSubject.getString("option_c"),
                                            objectSubject.getString("option_d"),
                                            objectSubject.getString("correct_option"),
                                            objectSubject.getString("explanation1"),
                                            objectSubject.getString("explanation2")
                                        )
                                    )
                                }
                                ADAPTER.addItems(dataArray)
                                loadQuestionToView()

                            }else{
                                Toast.makeText(this, "No questionszszasz", Toast.LENGTH_LONG).show()
                            }
                        } else {
                            Toast.makeText(this, "An error occurred while loading the subjects", Toast.LENGTH_LONG).show()
                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError ->

                    Toast.makeText(this, "Error in network connection. Swipe down to reload...", Toast.LENGTH_LONG).show()
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params.put("request_type", "get_cbt_questions")
                params.put("subject_id", selectedSubjectId)
                params.put("exam_type", selectedExamTypeId)
                params.put("topic_id", selectedTopicId)
                params.put("school_id", selectedSchoolId)
                params.put("exam_year", examYear)
                return params
            }
        }
        VolleySingleton.instance?.addToRequestQueue(stringRequest)//adding request to queue
        //volley interactions end
    }

    fun loadQuestionToView(){
        
    }
}
