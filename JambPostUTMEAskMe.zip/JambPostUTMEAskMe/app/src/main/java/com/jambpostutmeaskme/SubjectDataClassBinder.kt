package com.jambpostutmeaskme

data class SubjectList(val subject_id: String?, val subject_name: String?, val subject_logo: String?, val arrangement_order: String?) {}
data class TopicList(val topic_id: String?, val topic_name: String?, val topic_subject_id: String?, val topic_logo: String?, val arrangement_order: String?) {}
data class SchoolList(val school_id: String?, val school_name: String?, val school_code: String?, val school_logo: String?, val school_motto: String?, val school_type: String?) {}
data class DraftList(val draft_id: String?,val draft_subject_id: String?, val draft_topic_id: String?, val draft_msg_body: String?, val draft_img_url: String?
                     , val draft_option_a: String?, val draft_option_b: String?, val draft_option_c: String?, val draft_option_d: String?
                     , val draft_school_id: String?, val draft_question_source: String?) {}
data class VideoDataClassBinder(val video_id: String?, val video_url: String?, val video_title: String?, val video_cover: String?, val no_of_views: String?, val tutor_id: String?) {}
data class QuestionDataClassBinder(val question_id: String, val subject_id: String?, val topic_id: String?, val subject_name: String?, val topic_name: String?, val question_sub_or_topic: String?
                                   , val question_type: String?, val q_posted_time: String?, val q_img_path: String?, val q_body: String?
                                   , val q_poster: String?, val q_poster_id: String?, val q_no_of_answers: String?
                                   , val q_top_ans_no_of_likes: String?, val q_top_ans_poster: String?, val q_top_ans_body: String?, var type: Int = 0)
data class ExamQDataClassBinder(val question_id: String, val subject_id: String?, val topic_id: String?
                                   , val question_type: String?, val q_img_path: String?, val q_body: String?
                                   , val option_a: String?, val option_b: String?, val option_c: String?
                                   , val option_d: String?, val correct_option: String?, val explanation1: String?, var explanation2: String, var user_answered_option: String = "-1")
data class AnswersDataClassBinder(val answer_id: String?, val answer_msg_body: String?, val answer_type: String?
                                   , val answer_img_path: String?, val answer_date: String?, val answerer: String?,val answerer_id: String?, val no_of_likes: String?
                                  , val no_of_dislikes: String?, val vote_status: String?) {}
data class NewsDataClassBinder(val news_id: String?, val news_title: String?, val news_img_view: String?
                                   , val user_id: String?, val news_msg: String?, val news_date: String?) {}
data class Item(var name: String = "", var type: Int = 0)
