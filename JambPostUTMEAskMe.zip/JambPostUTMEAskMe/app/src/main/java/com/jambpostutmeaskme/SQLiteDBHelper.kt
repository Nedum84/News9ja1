package com.jambpostutmeaskme


import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

import java.util.ArrayList


class SQLiteDBHelper(val context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SQL_CREATE_ENTRIES_FOR_SUBJECTS)
        db.execSQL(SQL_CREATE_ENTRIES_FOR_TOPICS)
        db.execSQL(SQL_CREATE_ENTRIES_FOR_SAVED_QUESTIONS)
        db.execSQL(SQL_CREATE_ENTRIES_FOR_SCHOOLS)
        db.execSQL(SQL_CREATE_ENTRIES_FOR_DRAFTS)
    }


    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES_FOR_SUBJECTS)
        db.execSQL(SQL_DELETE_ENTRIES_FOR_TOPICS)
        db.execSQL(SQL_DELETE_ENTRIES_FOR_SAVED_QUESTIONS)
        db.execSQL(SQL_DELETE_ENTRIES_FOR_SCHOOLS)
        db.execSQL(SQL_DELETE_ENTRIES_FOR_DRAFTS)
        onCreate(db)
    }


    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onUpgrade(db, oldVersion, newVersion)
    }
     //insert subjects
    fun insertSubjects(data: SubjectList): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase

        // Create a new map of values, where column names are the keys
        val values = ContentValues()
        values.put(SUBJECT_ID, data.subject_id)
        values.put(SUBJECT_NAME, data.subject_name)
         values.put(SUBJECT_LOGO, data.subject_logo)
         values.put(SUBJECT_ARRANGEMENT_ORDER, data.arrangement_order)
        // Insert the new row, returning the primary key value of the new row
        val _success = db.insert(TABLE_NAME_SUBJECTS, null, values)
        db.close()
        return (Integer.parseInt("$_success") != -1)//RETURN TRUE IF SUCCESSFUL OTHERWISE FALSE
    }
    //update subjects
    fun updateSubjectList(data: SubjectList): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(SUBJECT_NAME, data.subject_name)
        values.put(SUBJECT_LOGO, data.subject_logo)

        val _success = db.update(TABLE_NAME_SUBJECTS, values, "$SUBJECT_ID=?", arrayOf(data.subject_id)).toLong()
        db.close()
        return Integer.parseInt("$_success") != -1
    }
    //get subjects
    fun getSubjects(): ArrayList<SubjectList> {

        val subjects = ArrayList<SubjectList>()
        val db = writableDatabase
        val cursor: Cursor?
        try {
            val selectQuery = "SELECT  * FROM $TABLE_NAME_SUBJECTS ORDER BY $SUBJECT_ARRANGEMENT_ORDER ASC"
            cursor = db.rawQuery(selectQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_SUBJECTS)
            return ArrayList()
        }

        if (cursor!!.moveToFirst()) {
            while (!cursor.isAfterLast) {

                subjects.add(SubjectList(
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(SUBJECT_ID))).toString(),
                        cursor.getString(cursor.getColumnIndex(SUBJECT_NAME)),
                        cursor.getString(cursor.getColumnIndex(SUBJECT_LOGO)),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(SUBJECT_ARRANGEMENT_ORDER))).toString()
                    )
                )
                cursor.moveToNext()
            }
        }
        cursor.close()
        return subjects
    }
    //checking if subject has been added
    fun checkIfSubjectExist(subject_id: String?):Boolean{
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            val checkQuery = "SELECT  * FROM $TABLE_NAME_SUBJECTS WHERE $SUBJECT_ID = $subject_id"
            cursor = db.rawQuery(checkQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_SUBJECTS)
        }
        val cursorCount = cursor!!.count
        cursor.close()
        return cursorCount >=1
    }





    //insert topics
    fun insertTopics(data: TopicList): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase

        // Create a new map of values, where column names are the keys
        val values = ContentValues()
        values.put(TOPIC_ID, data.topic_id)
        values.put(TOPIC_NAME, data.topic_name)
        values.put(TOPIC_SUBJECT_ID, data.topic_subject_id)
        values.put(TOPIC_LOGO, data.topic_logo)
        values.put(TOPIC_ARRANGEMENT_ORDER, data.arrangement_order)
        // Insert the new row, returning the primary key value of the new row
        val _success = db.insert(TABLE_NAME_TOPICS, null, values)
        db.close()
        return (Integer.parseInt("$_success") != -1)//RETURN TRUE IF SUCCESSFUL OTHERWISE FALSE
    }
    //update topics
    fun updateTopicList(data: TopicList): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(TOPIC_NAME, data.topic_name)
        values.put(TOPIC_SUBJECT_ID, data.topic_subject_id)
        values.put(TOPIC_LOGO, data.topic_logo)

        val _success = db.update(TABLE_NAME_TOPICS, values, "$TOPIC_ID=?", arrayOf(data.topic_id)).toLong()
        db.close()
        return Integer.parseInt("$_success") != -1
    }
    //get topics
    fun getTopics(subject_id :Int  = -1): ArrayList<TopicList> {

        val topics = ArrayList<TopicList>()
        val db = writableDatabase
        val cursor: Cursor?
        try {
            val selectQuery = if (subject_id != -1){
                   "SELECT  * FROM $TABLE_NAME_TOPICS WHERE $TOPIC_SUBJECT_ID = $subject_id ORDER BY $TOPIC_ARRANGEMENT_ORDER"
            }else{
                "SELECT  * FROM $TABLE_NAME_TOPICS ORDER BY $TOPIC_NAME ASC"
            }
            cursor = db.rawQuery(selectQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_SUBJECTS)
            return ArrayList()
        }

        if (cursor!!.moveToFirst()) {
            while (!cursor.isAfterLast) {
                topics.add(TopicList(
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(TOPIC_ID))).toString(),
                        cursor.getString(cursor.getColumnIndex(TOPIC_NAME)),
                        cursor.getString(cursor.getColumnIndex(TOPIC_SUBJECT_ID)),
                        cursor.getString(cursor.getColumnIndex(TOPIC_LOGO)),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(TOPIC_ARRANGEMENT_ORDER))).toString()
                    )
                )
                cursor.moveToNext()
            }
        }
        cursor.close()
        return topics
    }
    //checking for topic existence
    fun checkIfTopicExist(topic_id: String?):Boolean{
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            val checkQuery = "SELECT  * FROM $TABLE_NAME_TOPICS WHERE $TOPIC_ID = $topic_id"
            cursor = db.rawQuery(checkQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_TOPICS)
        }
        val cursorCount = cursor!!.count
        cursor.close()
        return cursorCount >=1
    }




    //insert schools
    fun insertSchools(data: SchoolList): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase

        // Create a new map of values, where column names are the keys
        val values = ContentValues()
        values.put(SCHOOL_ID, data.school_id)
        values.put(SCHOOL_NAME, data.school_name)
        values.put(SCHOOL_CODE, data.school_code)
        values.put(SCHOOL_LOGO, data.school_logo)
        values.put(SCHOOL_MOTTO, data.school_motto)
        values.put(SCHOOL_TYPE, data.school_type)
        // Insert the new row, returning the primary key value of the new row
        val _success = db.insert(TABLE_NAME_SCHOOLS, null, values)
        db.close()
        return (Integer.parseInt("$_success") != -1)//RETURN TRUE IF SUCCESSFUL OTHERWISE FALSE
    }
    //update school list
    fun updateSchoolList(data: SchoolList): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(SCHOOL_NAME, data.school_name)
        values.put(SCHOOL_CODE, data.school_code)
        values.put(SCHOOL_LOGO, data.school_logo)
        values.put(SCHOOL_MOTTO, data.school_motto)
        values.put(SCHOOL_TYPE, data.school_type)
        // Insert the new row, returning the primary key value

        val _success = db.update(TABLE_NAME_SCHOOLS, values, "$SCHOOL_ID=?", arrayOf(data.school_id)).toLong()
        db.close()
        return Integer.parseInt("$_success") != -1
    }
    //get SCHOOLS
    fun getSchools(): ArrayList<SchoolList> {

        val schools = ArrayList<SchoolList>()
        val db = writableDatabase
        val cursor: Cursor?
        try {
            val selectQuery = "SELECT  * FROM $TABLE_NAME_SCHOOLS"
            cursor = db.rawQuery(selectQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_SCHOOLS)
            return ArrayList()
        }

        if (cursor!!.moveToFirst()) {
            while (!cursor.isAfterLast) {

                schools.add(SchoolList(
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(SCHOOL_ID))).toString(),
                        cursor.getString(cursor.getColumnIndex(SCHOOL_NAME)),
                        cursor.getString(cursor.getColumnIndex(SCHOOL_CODE)),
                        cursor.getString(cursor.getColumnIndex(SCHOOL_LOGO)),
                        cursor.getString(cursor.getColumnIndex(SCHOOL_MOTTO)),
                        cursor.getString(cursor.getColumnIndex(SCHOOL_TYPE))
                    )
                )
                cursor.moveToNext()
            }
        }
        cursor.close()
        return schools
    }
    //checking for topic existence
    fun checkIfSchoolExist(id: String?):Boolean{
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            val checkQuery = "SELECT  * FROM $TABLE_NAME_SCHOOLS WHERE $SCHOOL_ID = $id"
            cursor = db.rawQuery(checkQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_SCHOOLS)
        }
        val cursorCount = cursor!!.count
        cursor.close()
        return cursorCount >=1
    }



    //insert drafts
    fun insertDrafts(data: DraftList): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase
        // Create a new map of values, where column names are the keys
        val values = ContentValues()
        values.put(DRAFT_SUBJECT_ID, data.draft_subject_id)
        values.put(DRAFT_TOPIC_ID, data.draft_topic_id)
        values.put(DRAFT_MSG_BODY, data.draft_msg_body)
        values.put(DRAFT_IMG_URL, data.draft_img_url)
        values.put(DRAFT_OPTION_A, data.draft_option_a)
        values.put(DRAFT_OPTION_B, data.draft_option_b)
        values.put(DRAFT_OPTION_C, data.draft_option_c)
        values.put(DRAFT_OPTION_D, data.draft_option_d)
        values.put(DRAFT_SCHOOL_ID, data.draft_school_id)
        values.put(DRAFT_QUESTION_SOURCE, data.draft_question_source)
        // Insert the new row, returning the primary key value of the new row
        val _success = db.insert(TABLE_NAME_DRAFTS, null, values)
        db.close()
        return (Integer.parseInt("$_success") != -1)//RETURN TRUE IF SUCCESSFUL OTHERWISE FALSE
    }
    //update drafts
    fun updateDraft(data: DraftList): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(DRAFT_SUBJECT_ID, data.draft_subject_id)
        values.put(DRAFT_TOPIC_ID, data.draft_topic_id)
        values.put(DRAFT_MSG_BODY, data.draft_msg_body)
        values.put(DRAFT_IMG_URL, data.draft_img_url)
        values.put(DRAFT_OPTION_A, data.draft_option_a)
        values.put(DRAFT_OPTION_B, data.draft_option_b)
        values.put(DRAFT_OPTION_C, data.draft_option_c)
        values.put(DRAFT_OPTION_D, data.draft_option_d)
        values.put(DRAFT_SCHOOL_ID, data.draft_school_id)
        values.put(DRAFT_QUESTION_SOURCE, data.draft_question_source)

        val _success = db.update(TABLE_NAME_SUBJECTS, values, "$DRAFT_ID=?", arrayOf(data.draft_id)).toLong()
        db.close()
        return Integer.parseInt("$_success") != -1
    }
    //get drafts
    fun getDrafts(id :Int): ArrayList<DraftList> {

        val drafts = ArrayList<DraftList>()
        val db = writableDatabase
        val cursor: Cursor?
        try {
            val selectQuery = "SELECT  * FROM $TABLE_NAME_SCHOOLS WHERE $SCHOOL_ID = $id "
            cursor = db.rawQuery(selectQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_SCHOOLS)
            return ArrayList()
        }

        if (cursor!!.moveToFirst()) {
            while (!cursor.isAfterLast) {

                drafts.add(DraftList(
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(DRAFT_ID))).toString(),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(DRAFT_SUBJECT_ID))).toString(),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(DRAFT_TOPIC_ID))).toString(),
                        cursor.getString(cursor.getColumnIndex(DRAFT_MSG_BODY)),
                        cursor.getString(cursor.getColumnIndex(DRAFT_IMG_URL)),
                        cursor.getString(cursor.getColumnIndex(DRAFT_OPTION_A)),
                        cursor.getString(cursor.getColumnIndex(DRAFT_OPTION_B)),
                        cursor.getString(cursor.getColumnIndex(DRAFT_OPTION_C)),
                        cursor.getString(cursor.getColumnIndex(DRAFT_OPTION_D)),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(DRAFT_SCHOOL_ID))).toString(),
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex(DRAFT_QUESTION_SOURCE))).toString()
                    )
                )
                cursor.moveToNext()
            }
        }
        cursor.close()
        return drafts
    }
    //checking for draft existence
    fun checkIfDraftExist(id: String?):Boolean{
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            val checkQuery = "SELECT  * FROM $TABLE_NAME_DRAFTS WHERE $DRAFT_ID = $id"
            cursor = db.rawQuery(checkQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_DRAFTS)
        }
        val cursorCount = cursor!!.count
        cursor.close()
        return cursorCount >=1
    }


    //save questions
    fun saveQuestion(question_id:String?): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase

        // Create a new map of values, where column names are the keys
        val values = ContentValues()
        values.put(SAVED_QUESTION_ID, question_id)
        // Insert the new row, returning the primary key value of the new row
        val _success = db.insert(TABLE_NAME_SAVED_QUESTIONS, null, values)
        db.close()
        return (Integer.parseInt("$_success") != -1)//RETURN TRUE IF SUCCESSFUL OTHERWISE FALSE
    }
    //delete saved questions
    @Throws(SQLiteConstraintException::class)
    fun deleteSavedQuestion(question_id: String?): Boolean {
        // Gets the data repository in write mode
        val db = writableDatabase
        val _success = db.delete(TABLE_NAME_SAVED_QUESTIONS, "$SAVED_QUESTION_ID = ?", arrayOf(question_id)).toLong()

        db.close()
        return Integer.parseInt("$_success") != -1
    }

    // check if question is saved
    fun checkIfQuestionIsSaved(question_id: Int?):Boolean{

        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            val checkQuery = "SELECT  * FROM $TABLE_NAME_SAVED_QUESTIONS WHERE $SAVED_QUESTION_ID = $question_id"
            cursor = db.rawQuery(checkQuery, null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES_FOR_SAVED_QUESTIONS)
        }
        val cursorCount = cursor!!.count
        cursor.close()
        return cursorCount >=1
    }






    companion object {
        // If you change the database schema, you must increment the database version.
        val DATABASE_VERSION        = 1
        val DATABASE_NAME           = "jambpostutmeask.db"

        //        subjects
        val TABLE_NAME_SUBJECTS          = "table_name_subjects"
        val SUBJECT_ID         = "subject_id"
        val SUBJECT_NAME         = "subject_name"
        val SUBJECT_LOGO         = "subject_logo"
        val SUBJECT_ARRANGEMENT_ORDER         = "subject_arrangement_order"
        private val SQL_CREATE_ENTRIES_FOR_SUBJECTS = "CREATE TABLE $TABLE_NAME_SUBJECTS " +
                "($SUBJECT_ID Integer PRIMARY KEY, $SUBJECT_NAME TEXT, $SUBJECT_LOGO TEXT, $SUBJECT_ARRANGEMENT_ORDER Integer)"

        private val SQL_DELETE_ENTRIES_FOR_SUBJECTS = "DROP TABLE IF EXISTS $TABLE_NAME_SUBJECTS"


        //        topics
        val TABLE_NAME_TOPICS          = "table_name_topics"
        val TOPIC_ID         = "topic_id"
        val TOPIC_NAME         = "topic_name"
        val TOPIC_SUBJECT_ID         = "topic_subject_id"
        val TOPIC_LOGO         = "topic_logo"
        val TOPIC_ARRANGEMENT_ORDER         = "topic_arrangement_order"
        private val SQL_CREATE_ENTRIES_FOR_TOPICS = "CREATE TABLE $TABLE_NAME_TOPICS " +
                "($TOPIC_ID Integer PRIMARY KEY, $TOPIC_NAME TEXT, $TOPIC_SUBJECT_ID Integer, $TOPIC_LOGO TEXT, $TOPIC_ARRANGEMENT_ORDER Integer)"

        private val SQL_DELETE_ENTRIES_FOR_TOPICS = "DROP TABLE IF EXISTS $TABLE_NAME_TOPICS"

//        FOR USERS'S SAVED QUESTION'
        val TABLE_NAME_SAVED_QUESTIONS = "table_name_saved_questions"
        val  SAVED_QUESTION_ID = "saved_question_id"
        val SQL_CREATE_ENTRIES_FOR_SAVED_QUESTIONS ="CREATE TABLE $TABLE_NAME_SAVED_QUESTIONS " +
                "($SAVED_QUESTION_ID Integer )"

        private val SQL_DELETE_ENTRIES_FOR_SAVED_QUESTIONS = "DROP TABLE IF EXISTS $TABLE_NAME_SAVED_QUESTIONS"


        //        SCHOOLS(university, poly & college of edu)
        val TABLE_NAME_SCHOOLS          = "table_name_schools"
        val SCHOOL_ID         = "school_id"
        val SCHOOL_NAME         = "school_name"
        val SCHOOL_CODE         = "school_code"
        val SCHOOL_LOGO         = "school_logo"
        val SCHOOL_MOTTO         = "school_motto"
        val SCHOOL_TYPE         = "school_type"
        private val SQL_CREATE_ENTRIES_FOR_SCHOOLS = "CREATE TABLE $TABLE_NAME_SCHOOLS " +
                "($SCHOOL_ID Integer PRIMARY KEY, $SCHOOL_NAME TEXT, $SCHOOL_CODE TEXT, $SCHOOL_LOGO TEXT, $SCHOOL_MOTTO TEXT, $SCHOOL_TYPE Integer)"

        private val SQL_DELETE_ENTRIES_FOR_SCHOOLS = "DROP TABLE IF EXISTS $TABLE_NAME_SCHOOLS"

        //        saved as draft questions
        val TABLE_NAME_DRAFTS     = "table_name_drafts"
        val DRAFT_ID            = "draft_id"
        val DRAFT_SUBJECT_ID         = "draft_subject_id"
        val DRAFT_TOPIC_ID         = "draft_topic_id"
        val DRAFT_MSG_BODY         = "draft_msg_body"
        val DRAFT_IMG_URL         = "draft_img_url"
        val DRAFT_OPTION_A         = "draft_option_a"
        val DRAFT_OPTION_B         = "draft_option_b"
        val DRAFT_OPTION_C         = "draft_option_c"
        val DRAFT_OPTION_D         = "draft_option_d"
        val DRAFT_SCHOOL_ID         = "draft_school_id"
        val DRAFT_QUESTION_SOURCE         = "draft_question_source"
        private val SQL_CREATE_ENTRIES_FOR_DRAFTS = "CREATE TABLE $TABLE_NAME_DRAFTS " +
                "($DRAFT_ID Integer PRIMARY KEY AUTOINCREMENT, $DRAFT_SUBJECT_ID Integer, $DRAFT_TOPIC_ID Integer, $DRAFT_MSG_BODY TEXT, " +
                "$DRAFT_IMG_URL TEXT, $DRAFT_OPTION_A TEXT,$DRAFT_OPTION_B TEXT, $DRAFT_OPTION_C TEXT, $DRAFT_OPTION_D TEXT, $DRAFT_SCHOOL_ID Integer" +
                ", $DRAFT_QUESTION_SOURCE Integer)"

        private val SQL_DELETE_ENTRIES_FOR_DRAFTS = "DROP TABLE IF EXISTS $TABLE_NAME_DRAFTS"

    }

}