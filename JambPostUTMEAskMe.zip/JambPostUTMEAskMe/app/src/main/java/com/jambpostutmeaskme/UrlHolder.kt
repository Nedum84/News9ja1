package com.jambpostutmeaskme

object  UrlHolder{
    const val YOUTUBE_DEVELOPER_KEY = "AIzaSyCuuIkzweg_5prNp8uKGXtO48JavZuUPUo"
    private const val URL_ROOT = "http://192.168.44.236/tutorials/server_request/"
//    val URL_VIDEO_FULL_PATH: String?= "http://192.168.44.236/tutorials/uploadsz/topicsz_videoz/"
//    private const val URL_ROOT = "http://192.168.43.168/tutorials/server_request/"
//    private val URL_ROOT = "http://10.0.2.2/tutorials/server_request/"
//    private val URL_ROOT = "http://toppersacad.com/jambtutorial/server_request/"
    val URL_VIDEO_FULL_PATH: String?= "http://toppersacad.com/jambtutorial/uploadsz/topicsz_videoz/"
    val URL_REGISTER = URL_ROOT + "register.php"
    val URL_LOGIN = URL_ROOT + "login.php"
    val URL_GET_SUBJECTS = URL_ROOT + "get_subjects.php"
    val URL_GET_SUBJECT_TOPICS = URL_ROOT + "get_subject_topics.php"
    val URL_GET_TOPIC_VIDEOS = URL_ROOT + "get_topic_videos.php"
    val URL_GET_TOPIC_QUESTIONS= URL_ROOT + "get_topic_questions.php"
    val URL_GET_NEWS_FEED= URL_ROOT + "get_news_feed.php"
    val URL_GET_QUESTIONS_ANSWERS= URL_ROOT + "get_question_answers.php"
    val URL_ADD_QUESTIONS= URL_ROOT + "add_question.php"
    val URL_ADD_QUESTION_COMMENTS= URL_ROOT + "add_question_comments.php"
    val URL_UPDATE_NO_OF_VIEWS= URL_ROOT + "update_no_of_views.php"
    val URL_EDIT_PROFILE = URL_ROOT + "edit_profile.php"
    val URL_CHANGE_PASSWORD = URL_ROOT + "change_password.php"
    val URL_RESET_PASSWORD = URL_ROOT + "reset_password.php"
    val URL_GET_APP_DETAILS: String? = URL_ROOT + "get_app_details.php"
    val URL_SUBMIT_FEEDBACK_MSG: String?= URL_ROOT + "submit_feedback_msg.php"
    val URL_SUBMIT_VOTING: String?= URL_ROOT + "answer_votes.php"




    val URL_GET_QUESTIONS = URL_ROOT + "get_questions.php"
    val URL_ADD_QUESTION= URL_ROOT + "add_question.php"
    val URL_ADD_QUESTION_ANSWERS= URL_ROOT + "add_question_answers.php"
}