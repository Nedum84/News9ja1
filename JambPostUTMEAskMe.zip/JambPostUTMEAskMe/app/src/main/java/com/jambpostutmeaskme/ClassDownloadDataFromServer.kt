package com.jambpostutmeaskme

import android.content.Context
import android.os.Environment
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import org.json.JSONException
import org.json.JSONObject
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.URL
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.util.ArrayList
import android.opengl.ETC1.getHeight
import android.opengl.ETC1.getWidth




class ClassDownloadDataFromServer(var context: Context) {
    var sqLiteDBHelper : SQLiteDBHelper = SQLiteDBHelper(context)

    fun downLoadSubjectsAndTopics(){

        //creating volley string request
        val stringRequest = object : StringRequest(Request.Method.POST, UrlHolder.URL_GET_SUBJECTS,
                Response.Listener<String> { response ->

                    try {
                        val obj = JSONObject(response)
                        if (!obj.getBoolean("error")) {
                            val noOfSubjects = obj.getJSONArray("subject_list_arrayzs")
                            val noOfTopics = obj.getJSONArray("topic_arrayzs")
                            val noOfSchools = obj.getJSONArray("school_arrayzs")

                            //for subjects
                            for (i in 0 until noOfSubjects.length()) {
                                val eachList = noOfSubjects.getJSONObject(i)

                                if (!sqLiteDBHelper.checkIfSubjectExist(eachList.getString("subject_id"))){

                                    val eachRow = SubjectList(
                                            eachList.getString("subject_id"),
                                            eachList.getString("subject_name"),
                                            eachList.getString("subject_logo"),
                                            eachList.getString("arrangement_order")
                                        )
                                    sqLiteDBHelper.insertSubjects(eachRow)
                                }else{

                                    val eachRow = SubjectList(
                                            eachList.getString("subject_id"),
                                            eachList.getString("subject_name"),
                                            eachList.getString("subject_logo"),
                                            eachList.getString("arrangement_order")
                                        )
                                    sqLiteDBHelper.updateSubjectList(eachRow)

                                }
                            }


                            //for topics
                            for (k in 0 until noOfTopics.length()) {
                                val eachList = noOfTopics.getJSONObject(k)

                                if (!sqLiteDBHelper.checkIfTopicExist(eachList.getString("topic_id"))){

                                    val eachRow = TopicList(
                                            eachList.getString("topic_id"),
                                            eachList.getString("topic_name"),
                                            eachList.getString("topic_subject_id"),
                                            eachList.getString("topic_logo"),
                                            eachList.getString("arrangement_order")
                                    )
                                    sqLiteDBHelper.insertTopics(eachRow)
                                }else{

                                    val eachRow = TopicList(
                                            eachList.getString("topic_id"),
                                            eachList.getString("topic_name"),
                                            eachList.getString("topic_subject_id"),
                                            eachList.getString("topic_logo"),
                                            eachList.getString("arrangement_order")
                                    )
                                    sqLiteDBHelper.updateTopicList(eachRow)

                                }
                            }


                            //for schools
                            for (x in 0 until noOfSchools.length()) {
                                val eachList = noOfSchools.getJSONObject(x)

                                if (!sqLiteDBHelper.checkIfSchoolExist(eachList.getString("school_id"))){

                                    val eachRow = SchoolList(
                                            eachList.getString("school_id"),
                                            eachList.getString("school_name"),
                                            eachList.getString("school_code"),
                                            eachList.getString("school_logo"),
                                            eachList.getString("school_motto"),
                                            eachList.getString("school_type")
                                    )
                                    sqLiteDBHelper.insertSchools(eachRow)
                                }else{

                                    val eachRow = SchoolList(
                                            eachList.getString("school_id"),
                                            eachList.getString("school_name"),
                                            eachList.getString("school_code"),
                                            eachList.getString("school_logo"),
                                            eachList.getString("school_motto"),
                                            eachList.getString("school_type")
                                    )
                                    sqLiteDBHelper.updateSchoolList(eachRow)

                                }
                            }
                        } else {
                            Toast.makeText(context, "An error occurred while loading data... ", Toast.LENGTH_LONG).show()
                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError ->
                    //if empty, there's n/w failure
                    Toast.makeText(context, volleyError.message+"---- n/w", Toast.LENGTH_SHORT).show()
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params.put("request_type", "get_subs_topics_and_schools")
                return params
            }
        }
        VolleySingleton.instance?.addToRequestQueue(stringRequest)//adding request to queue
        //volley interactions end
    }


}