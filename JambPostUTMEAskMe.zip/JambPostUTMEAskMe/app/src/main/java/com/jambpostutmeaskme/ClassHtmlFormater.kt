package com.jambpostutmeaskme

import android.text.Html
import android.text.Spanned
import android.graphics.drawable.Drawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.Bitmap
import android.graphics.Canvas
import android.widget.TextView


class ClassHtmlFormater {

    @Suppress("DEPRECATION")
    fun fromHtml(html: String?): Spanned {
        val result: Spanned
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            result = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        } else {
            result = Html.fromHtml(html!!.replace("&lt;", "<").replace("&gt;", ">"))
//            result = Html.fromHtml("<![CDATA[$html]]>");
        }
        return result
    }
    fun formatedString(str:String){
        fromHtml(formatTags(str))
    }
    fun formatTags(dataString:String):String{

//        val dataString = "he*llo #world#?30/8987? of ?5/78?"
        val superScriptIcon="*"
        val subScriptIcon="#"
        val factionScriptIcon="?"
        var newData = ""
        var supCounter = 1
        var subCounter = 1
        var fracCounter = 1
        var fracCheck = false
        for (i in dataString.indices){
            var dData = dataString[i].toString()
            //SUPERSCRIPT

            if (checkNoOfOccurence(dataString,superScriptIcon) !=1){
                if (dData == superScriptIcon){
                    dData = if (supCounter.rem(2) == 1){//odd val
                        "<sup><small>"
                    }else{//even
                        "</small></sup>"
                    }
                    supCounter++
                }
            }
            //SUBSCRIPT
            if (checkNoOfOccurence(dataString,subScriptIcon) !=1){
                if (dData == subScriptIcon){
                    dData = if (subCounter.rem(2) == 1){//odd val
                        "<sub><small>"
                    }else{//even
                        "</small></sub>"
                    }
                    subCounter++
                }
            }
            //FRACTION
            if (checkNoOfOccurence(dataString,factionScriptIcon) !=1){
                if(dData == factionScriptIcon){
                    if (fracCounter.rem(2) == 1){//odd val
                        fracCheck =true
                        dData = "<sup><small>"
                    }else{//even
                        dData = "</small></sub>"
                        fracCheck =false
                    }
                    fracCounter++
                }
                if(fracCheck&&dData=="/"){
                    dData = "</small></sup>/<sub><small>"
                }
            }
            newData += dData



//            print(newData)
        }

        return newData
    }
    fun checkNoOfOccurence(data:CharSequence,comparator:String):Int{
        var counter = 0
        for (i in data.indices){
            if (data[i].toString() == comparator){
                counter++
            }
        }

        return counter
    }

    fun replaceTags(html: String?) :String{
        return html!!.replace("h2so4", "H<sub>2</sub>SO<sub>4</sub>").replace("hcl", "HCl")
                .replace("caco3", "CaCO<sub>3</sub>").replace("no2", "NO<sub>2</sub>")
                .replace("h20", "H<sub>2</sub>O").replace("naoh", "NaOH")
                .replace("caso4", "CaSO<sub>4</sub>").replace("naso4", "Na<sub>2</sub>SO<sub>4</sub>")
    }
}

//class PicassoImageGetter(target: TextView) : Html.ImageGetter {
//
//    private var textView = target
//
//    override fun getDrawable(source: String): Drawable {
//        val drawable = BitmapDrawablePlaceHolder()
//        Picasso.with(App.get())
//                .load(source)
//                .placeholder(R.drawable.img_loading)
//                .into(drawable)
//        return drawable
//    }
//
//    private inner class BitmapDrawablePlaceHolder : BitmapDrawable(), Target() {
//
//        protected var drawable: Drawable? = null
//
//        override fun draw(canvas: Canvas) {
//            if (drawable != null) {
//                drawable!!.draw(canvas)
//            }
//        }
//
//        fun setDrawablez(drawable: Drawable) {
//            this.drawable = drawable
//            val width = drawable.intrinsicWidth
//            val height = drawable.intrinsicHeight
//            drawable.setBounds(0, 0, width, height)
//            setBounds(0, 0, width, height)
//            if (textView != null) {
//                textView!!.setText(textView!!.getText())
//            }
//        }
//
//        fun onBitmapLoaded(bitmap: Bitmap, from: Picasso.LoadedFrom) {
//            setDrawablez(
//                    BitmapDrawable(App.get().getResources(), bitmap)
//            )
//        }
//
//        fun onBitmapFailed(errorDrawable: Drawable) {}
//
//        fun onPrepareLoad(placeHolderDrawable: Drawable) {
//
//        }
//
//    }
//}