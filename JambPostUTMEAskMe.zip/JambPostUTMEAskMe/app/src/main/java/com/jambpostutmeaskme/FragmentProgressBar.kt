package com.jambpostutmeaskme


import android.app.Dialog
import android.os.Bundle
import android.support.v4.app.Fragment
import android.graphics.PorterDuff
import android.widget.ProgressBar
import android.view.KeyEvent.KEYCODE_SEARCH
import android.view.KeyEvent.KEYCODE_BACK
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Window.FEATURE_NO_TITLE
import android.support.annotation.NonNull
import android.support.v4.app.DialogFragment
import android.view.*


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class FragmentProgressBar : DialogFragment() {


    fun getInstance(): FragmentProgressBar {
        val fragment = FragmentProgressBar()
        val args = Bundle()
        fragment.arguments = args
        return fragment
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_fragment_progress_bar, null, false)
        val progressBar = view.findViewById(R.id.progress) as ProgressBar
        progressBar.indeterminateDrawable.setColorFilter(context!!.resources.getColor(R.color.colorAccent),PorterDuff.Mode.SRC_IN)
        return view
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
       super.onCreateDialog(savedInstanceState)
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        // タッチしても消えないように設定
        dialog.setCancelable(false)
        // ビュー全体のリスナ
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnKeyListener { _, keyCode, event ->
            // Disable Back key and Search key
            when (keyCode) {
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_SEARCH -> true
                else -> false
            }
        }
        return dialog
    }


}
