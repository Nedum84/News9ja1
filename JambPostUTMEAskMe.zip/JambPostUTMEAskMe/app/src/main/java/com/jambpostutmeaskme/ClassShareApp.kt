package com.jambpostutmeaskme

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.content.ContextCompat.startActivity
//import com.thefinestartist.utils.content.ResourcesUtil.getString
import java.util.ArrayList

class ClassShareApp(val context: Context) {
//    private var newsListDBHelper : SQLiteNewsDBHelper
//    private lateinit var getNewsRow:NewsListClassBinder
//
//    private val appPackageName:String? = context.packageName // getPackageName() from Context or Activity object
//    val intent :Intent = Intent()
//    private val shareAppMsg:String =
//                            "Download \"9ja News Updates\" from Google Play Store via \n" +
//                            "https://play.google.com/store/apps/details?id=$appPackageName & get Real time updates from all the Nigerian Newspapers/Blogs every minutes"
//    init {
//        intent.action = Intent.ACTION_SEND
//        intent.type = "text/plain"
//        newsListDBHelper = SQLiteNewsDBHelper(context)
//    }
//    fun shareApp(){
//        intent.putExtra(Intent.EXTRA_TEXT,shareAppMsg)
//        startActivity(context, Intent.createChooser(intent,"Share to: "), Bundle())
//    }
//    private fun getNews2Share(newsLists: ArrayList<NewsListClassBinder>) {
//
//        for (newsRow: NewsListClassBinder in newsLists) {
//            getNewsRow = NewsListClassBinder(
//                    newsRow.table_id,
//                    newsRow.news_id,
//                    newsRow.news_list_id,
//                    newsRow.news_category,
//                    newsRow.news_url,
//                    newsRow.news_title,
//                    newsRow.news_img_urls,
//                    newsRow.news_content_body,
//                    newsRow.news_date_int,
//                    newsRow.news_no_of_views,
//                    newsRow.news_no_of_comments,
//                    newsRow.news_hide,
//                    newsRow.news_is_bookmarked
//            )
//        }
//
//        var devShareMsg:String?
//        devShareMsg = "9ja News Updates \n"
//        devShareMsg += ClassDateAndTime().getDateTime2(getNewsRow.news_date_int!!.toLong())+"\n"
//        devShareMsg += getNewsRow.news_title?.toUpperCase()+"\n"
//        devShareMsg += ClassHtmlFormater().removeHtmlTags(getNewsRow.news_content_body)+"\n\n"
//        devShareMsg+= "*SOURCE: _${newsListDBHelper.readNewsListDetails(getNewsRow.news_list_id)[0][1]}_*\n\n"
//
//        devShareMsg+= shareAppMsg
//
//
//        intent.putExtra(Intent.EXTRA_TEXT,devShareMsg)
//        startActivity(context, Intent.createChooser(intent,"Share to: "), Bundle())
//    }
//    fun shareNewsPost(news_id:Int){
//        getNews2Share(newsListDBHelper.readSingleNewsDetails(news_id))
//    }

}