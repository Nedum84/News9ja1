package com.jambpostutmeaskme

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.activity_question_solutions.*
import kotlinx.android.synthetic.main.alert_dialog_inflate_filter_answers.view.*
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class ActivityQuestionSolutions : AppCompatActivity() {
    private var answersList = mutableListOf<AnswersDataClassBinder>()
    lateinit var thisContext: Context
    lateinit var sqLiteDBHelper: SQLiteDBHelper

    val linearLayoutManager = LinearLayoutManager(this)
    lateinit var ADAPTER : AnswersAdapter
    var orderBy = "0"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question_solutions)
        setSupportActionBar(toolbar)
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowHomeEnabled(true)
        thisContext = this
        sqLiteDBHelper = SQLiteDBHelper(thisContext)
        addTitle()



        q_ans_order_by.setOnClickListener {
            showOrderByDialog()
        }

        ADAPTER = AnswersAdapter(answersList,thisContext)
        q_ans_recycler.layoutManager = linearLayoutManager
        q_ans_recycler.itemAnimator = DefaultItemAnimator()
        q_ans_recycler.adapter = ADAPTER

        loadAnswerDetails()
    }
    private fun addTitle(){
        val preference = ClassSharePreference(thisContext)
        toolbar.title = preference.getCurrentSubjectName()
        toolbar.subtitle = if(preference.getCurrentTopicName() =="-1" || preference.getCurrentTopicName() ==""|| preference.getCurrentTopicName() =="null"){
            "No Topic..."
        }else{
            preference.getCurrentTopicName()
        }
    }
    private fun showOrderByDialog(){

        val inflater = LayoutInflater.from(thisContext).inflate(R.layout.alert_dialog_inflate_filter_answers, null)
        val builder = AlertDialog.Builder(thisContext)
        builder.setView(inflater)
        val alertDialog = builder.create()
        alertDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        alertDialog.show()
        if(orderBy =="0"||orderBy =="1"){
            inflater.order_by_oldest_btn.isChecked = true
            inflater.order_by_votes_btn.isChecked = false
        }else if(orderBy =="2"){
            inflater.order_by_votes_btn.isChecked = true
            inflater.order_by_oldest_btn.isChecked = false
        }


        //order by oldest
        inflater.order_by_oldest.setOnClickListener {
            orderBy = "1"
//            refreshA()
            order()
            alertDialog.dismiss()
        }
        //order by votes
        inflater.order_by_votes.setOnClickListener {
            orderBy = "2"
//            refreshA()
            order()
            alertDialog.dismiss()
        }

    }

    private fun order() {

        Collections.sort(answersList, object : Comparator<AnswersDataClassBinder> {
            override fun compare(o1: AnswersDataClassBinder?, o2: AnswersDataClassBinder?): Int {
                var comparator1:String? = ""
                var comparator2:String? = ""
                if(orderBy == "1"){//sort by oldest
                    comparator1 = (o1 as AnswersDataClassBinder).answer_date
                    comparator2 = (o2 as AnswersDataClassBinder).answer_date

                }else{//sort by no of likes (votes)
                    comparator1 = (o1 as AnswersDataClassBinder).no_of_likes
                    comparator2 = (o2 as AnswersDataClassBinder).no_of_likes

                }
                val sComp = comparator1!!.compareTo(comparator2!!)

                if (sComp != 0) {
                    return sComp
                }

//                val x1 = (o1 as Person).getAge()//additional (secondary) sort
//                val x2 = (o2 as Person).getAge()//additional (secondary) sort
                return comparator1.compareTo(comparator2)

            }

        })


        if(orderBy =="2")answersList.reverse()//reverse number of likes
        ADAPTER.notifyDataSetChanged()
    }
    private fun upDateQuestionDiv(details: JSONObject){

        if (details.getString("question_type")=="image"){
            Glide.with(this)
                    .load(details.getString("question_img_url"))
                    .apply(RequestOptions()
//                            .placeholder(R.drawable.q_mark1)//default image on loading
                            .error(R.drawable.q_mark1)//without n/w, this img shows
                            .fitCenter()
                            .dontAnimate()
                            .dontTransform()
                    )
//                    .thumbnail(.1f)
                    .into(question_img_path)
        }
        val content = SpannableString(details.getString("no_of_answers"))
        content.setSpan(UnderlineSpan(), 0, content.length, 0)
        q_no_of_ans.text = content

        q_date_created.text     ="${details.getString("q_poster")} - "+ ClassDateAndTime().checkDateTimeFirst(details.getString("date_created").toLong())

        if (details.getString("msg_body")==""){
            q_msg_body.visibility = View.INVISIBLE
        }else{
            q_msg_body.text = ClassHtmlFormater().fromHtml(details.getString("msg_body"))

        }




        val currentQuestionId = ClassSharePreference(thisContext).getCurrentQuestionId()
        if (sqLiteDBHelper.checkIfQuestionIsSaved(currentQuestionId!!.toInt())){//saved
            savedBtn.visibility = View.VISIBLE
        }else{
            saveBtn.visibility = View.VISIBLE
        }

        saveBtn.setOnClickListener{
            //update DB
            sqLiteDBHelper.saveQuestion(currentQuestionId)

            saveBtn.visibility = View.GONE
            savedBtn.visibility = View.VISIBLE
        }
        savedBtn.setOnClickListener{
            //update DB
            sqLiteDBHelper.deleteSavedQuestion(currentQuestionId)

            savedBtn.visibility = View.GONE
            saveBtn.visibility = View.VISIBLE

        }
    }
    private fun loadAnswerDetails(order_by:String = "1") {

        //creating volley string request
        val stringRequest = object : StringRequest(Request.Method.POST, UrlHolder.URL_GET_QUESTIONS_ANSWERS,
                com.android.volley.Response.Listener<String> { sub ->

                    try {
                        val obj = JSONObject(sub)
                        if (!obj.getBoolean("error")) {
                            val answerszArray = obj.getJSONArray("answersz_array")

                            val ansDetailsArray = mutableListOf<AnswersDataClassBinder>()
                            for (i in 0 until answerszArray.length()) {
                                val objectSubject = answerszArray.getJSONObject(i)
                                ansDetailsArray.add(
                                        AnswersDataClassBinder(
                                                objectSubject.getString("answer_id"),
                                                objectSubject.getString("answer_msg_body"),
                                                objectSubject.getString("answer_type"),
                                                objectSubject.getString("answer_img_path"),
                                                objectSubject.getString("answer_date"),
                                                objectSubject.getString("answerer"),
                                                objectSubject.getString("answerer_id"),
                                                objectSubject.getString("no_of_likes"),
                                                objectSubject.getString("no_of_dislikes"),
                                                objectSubject.getString("vote_status")
                                            )
                                )
                            }
                            ADAPTER.addItems(ansDetailsArray)

                            val questionDetailsArray = obj.getJSONArray("question_details_array").getJSONObject(0)
                            upDateQuestionDiv(questionDetailsArray)


                        } else {
                            Toast.makeText(applicationContext, "An error occurred while loading the subjects", Toast.LENGTH_LONG).show()
                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError ->
                    Toast.makeText(applicationContext, volleyError.message, Toast.LENGTH_LONG).show() })
        {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params.put("request_type", "get_question_answers")
                params.put("question_id", ClassSharePreference(thisContext).getCurrentQuestionId())
                params.put("user_id", ClassSharePreference(thisContext).getUserDetails("id"))
                params.put("order_by", order_by)
                return params
            }
        }
        VolleySingleton.instance?.addToRequestQueue(stringRequest)//adding request to queue
        //volley interactions end
    }

    private fun refreshA(){
        clearAnswersList()
        ADAPTER.addItems(answersList)
        ADAPTER.notifyDataSetChanged()
        loadAnswerDetails(orderBy)
    }
    private fun clearAnswersList() {
        val size = answersList.size
        if (size > 0) {
            for (i in 0 until size) {
                answersList.removeAt(0)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                super.onBackPressed()
            }
            else -> return super.onOptionsItemSelected(item)
        }

        return true
    }
}
