package com.jambpostutmeaskme

import android.content.Context
import android.widget.Toast

class  ClassSharePreference(val context: Context?){

    private val PREFERENCE_NAME = "subjects_interactions_preference"
    private val PREFERENCE_ALL_SUBJECTS = "all_subjects"
    private val PREFERENCE_CURRENT_SUB_ID = "current_subject_id"
    private val PREFERENCE_CURRENT_SUB_NAME = "current_subject_name"
    private val PREFERENCE_CURRENT_TOPIC_ID = "current_topic_id"
    private val PREFERENCE_CURRENT_TOPIC_NAME = "current_topic_name"
    private val PREFERENCE_CURRENT_ANSWER_ID = "current_answer_id"
    private val PREFERENCE_CURRENT_VIDEO_ID = "current_video_id"
    private val PREFERENCE_REDIRECT_TO_LOGIN = "redirect_to_login"
    private val PREFERENCE_CURRENT_HOME_ACTIVITY_TITLE = "home_activity_title"
    private val PREFERENCE_SCHOOL_ID= "school_id"
    private val PREFERENCE_POSTER_ID= "poster_id"
    private val PREFERENCE_POSTER_NAME= "poster_name"
    private val PREFERENCE_Q_IMG_URL= "q_img_url"
    private val PREFERENCE_EXAM_TYPE= "current_exam_type"
    private val PREFERENCE_ANSWERED_STATUS= "current_answered_status"
    private val PREFERENCE_SCAN_CHECK= "scan_check_from_crop_activity"

    //user login details
    private val PREFERENCE_LOGGED_IN_DETAILS = "loggedInPreferenceName"
    private val PREFERENCE_USER_ID = "login_user_id"
    private val PREFERENCE_USER_NAME = "login_user_name"
    private val PREFERENCE_USER_USERNAME = "login_user_username"
    private val PREFERENCE_USER_EMAIL = "login_user_email"
    private val PREFERENCE_USER_MOBILE_NO = "login_user_mobile_no"
    private val PREFERENCE_USER_MEMBER_ID = "login_user_member_id"
    private val PREFERENCE_USER_PROFILE_PICTURE = "login_user_profile_picture"

    private val loggedInPreference = context?.getSharedPreferences(PREFERENCE_LOGGED_IN_DETAILS,Context.MODE_PRIVATE)!!
    private val preference = context?.getSharedPreferences(PREFERENCE_NAME,Context.MODE_PRIVATE)!!

    //set subjects
    fun setSubjects(subjects:String){
        val editor = preference.edit()
        editor.putString(PREFERENCE_ALL_SUBJECTS,subjects)
        editor.apply()
    }
    //get current sub id
    fun getSubjects():String?{
        return  preference.getString(PREFERENCE_ALL_SUBJECTS,"1")
    }
    //set subject name
    fun setCurrentSubjectName(subject_name:String?){
        val editor = preference.edit()
        editor.putString(PREFERENCE_CURRENT_SUB_NAME,subject_name)
        editor.apply()
    }
    //get current sub name
    fun getCurrentSubjectName():String?{
        return  preference.getString(PREFERENCE_CURRENT_SUB_NAME,"1")
    }
    //set current sub id
    fun setCurrentSubjectId(subject_id:String?){
        val editor = preference.edit()
        editor.putString(PREFERENCE_CURRENT_SUB_ID,subject_id)
        editor.apply()
    }
    //get current sub id
    fun getCurrentSubjectId() : String?{
        return  preference.getString(PREFERENCE_CURRENT_SUB_ID,"-1")
    }
    //    get current subject topic
    fun getCurrentTopicName():String?{
        return  preference.getString(PREFERENCE_CURRENT_TOPIC_NAME,"0")
    }
    //set current subject_name
    fun setCurrentTopicName(topic_name:String?){
        val editor = preference.edit()
        editor.putString(PREFERENCE_CURRENT_TOPIC_NAME,topic_name)
        editor.apply()
    }
    //set current subject_topic
    fun setCurrentTopicId(topic_id:String?){
        val editor = preference.edit()
        editor.putString(PREFERENCE_CURRENT_TOPIC_ID,topic_id)
        editor.apply()
    }
    //    get current subject name
    fun getCurrentTopicId():String?{
        return  preference.getString(PREFERENCE_CURRENT_TOPIC_ID,"0")
    }
    //set current subject_topic
    fun setCurrentQuestionId(question_id:String?){
        val editor = preference.edit()
        editor.putString(PREFERENCE_CURRENT_ANSWER_ID,question_id)
        editor.apply()
    }
    //    get current subject topic
    fun getCurrentQuestionId():String?{
        return  preference.getString(PREFERENCE_CURRENT_ANSWER_ID,"0")
    }
    //set current subject_topic
    fun setCurrentVideoDetails(video_details:String?){
        val editor = preference.edit()
        editor.putString(PREFERENCE_CURRENT_VIDEO_ID,video_details)
        editor.apply()
    }
    //    get current subject topic
    fun getCurrentVideoDetails():String?{
        return  preference.getString(PREFERENCE_CURRENT_VIDEO_ID,"0")
    }
    //set redirection path
    fun setRedirectToLogin(redirectToLogin:Boolean){
        val editor = preference.edit()
        editor.putBoolean(PREFERENCE_REDIRECT_TO_LOGIN,redirectToLogin)
        editor.apply()
    }
    //    get current subject topic
    fun redirectToLogin():Boolean{
        return  preference.getBoolean(PREFERENCE_REDIRECT_TO_LOGIN,false)
    }

    //    display home activity title
    fun setCurrentHomeActivityTitle(screenTitle: String?) {
        val editor = preference.edit()
        editor.putString(PREFERENCE_CURRENT_HOME_ACTIVITY_TITLE,screenTitle)
        editor.apply()
    }
    //    get current subject topic
    fun getCurrentHomeActivityTitle():String?{
        return  preference.getString(PREFERENCE_CURRENT_HOME_ACTIVITY_TITLE, "Tutorial" )
    }
    //set SchoolId
    fun setSchoolId(q_code:Int){
        val editor = preference.edit()
        editor.putInt(PREFERENCE_SCHOOL_ID,q_code)
        editor.apply()
    }
    //get SchoolId
    fun getSchoolId():Int?{
        return  preference.getInt(PREFERENCE_SCHOOL_ID,-1)//1->subject, 2->topic, 3->posterQuestions(the user that posted the question), 4->myQuestions
    }
    //set poster id
    fun setPosterId(q_code:String){
        val editor = preference.edit()
        editor.putString(PREFERENCE_POSTER_ID,q_code)
        editor.apply()
    }
    //get poster id
    fun getPosterId():String?{
        return  preference.getString(PREFERENCE_POSTER_ID,"-1")
    }

    //get poster name
    fun getPosterName():String?{
        return  preference.getString(PREFERENCE_POSTER_NAME,"JAMB & POST UTME Ask Me")
    }
    //set poster name
    fun setPosterName(name:String){
        val editor = preference.edit()
        editor.putString(PREFERENCE_POSTER_NAME,name)
        editor.apply()
    }

    //get Exam Type
    fun getExamType():String?{
        return  preference.getString(PREFERENCE_EXAM_TYPE,"-1")
    }
    //set Exam Type
    fun setExamType(name:String){
        val editor = preference.edit()
        editor.putString(PREFERENCE_EXAM_TYPE,name)
        editor.apply()
    }

    //get AnsweredStatus
    fun getAnsweredStatus():String?{
        return  preference.getString(PREFERENCE_ANSWERED_STATUS,"-1")
    }
    //set AnsweredStatus
    fun setAnsweredStatus(name:String){
        val editor = preference.edit()
        editor.putString(PREFERENCE_ANSWERED_STATUS,name)
        editor.apply()
    }

    //set question img for cropping
    fun setQImgUrl(url:String){
        val editor = preference.edit()
        editor.putString(PREFERENCE_Q_IMG_URL,url)
        editor.apply()
    }
    //get question img for cropping
    fun getQImgUrl():String{
        return  preference.getString(PREFERENCE_Q_IMG_URL,"")!!
    }

    //scan text?
    fun setScanCheck(url:String){
        val editor = preference.edit()
        editor.putString(PREFERENCE_SCAN_CHECK,url)
        editor.apply()
    }
    //get question img for cropping
    fun getScanCheck():String{
        return  preference.getString(PREFERENCE_SCAN_CHECK,"")!!
    }


    fun reset(){
        setCurrentSubjectId("-1")
        setCurrentSubjectName("")
        setCurrentTopicId("-1")
        setCurrentTopicName("")
        setPosterId("-1")
        setPosterName("")
        setAnsweredStatus("-1")
        setExamType("-1")
        setSchoolId(-1)
    }
    fun clear(){
        val userEditor = preference.edit()
        userEditor.clear()
        userEditor.apply()
    }








    //user login  details
    //store login details
    fun saveLoginDetails(login_user_id:String?,login_user_name:String?,login_user_username:String?,login_user_email:String?,login_user_mobile_no:String?,login_user_member_id:String?,login_user_profile_picture:String?):Boolean{
        val userEditor = loggedInPreference.edit()
        userEditor.putString(PREFERENCE_USER_ID,login_user_id)
        userEditor.putString(PREFERENCE_USER_NAME,login_user_name)
        userEditor.putString(PREFERENCE_USER_USERNAME,login_user_username)
        userEditor.putString(PREFERENCE_USER_EMAIL,login_user_email)
        userEditor.putString(PREFERENCE_USER_MOBILE_NO,login_user_mobile_no)
        userEditor.putString(PREFERENCE_USER_MEMBER_ID,login_user_member_id)
        userEditor.putString(PREFERENCE_USER_PROFILE_PICTURE,login_user_profile_picture)
        userEditor.apply()

        return true
    }
    //    get current subject topic
    fun getUserDetails(id:String):String?{
        return when (id) {
            "id" -> loggedInPreference.getString(PREFERENCE_USER_ID,"2")//-1
            "name" -> loggedInPreference.getString(PREFERENCE_USER_NAME,null)
            "username" -> loggedInPreference.getString(PREFERENCE_USER_USERNAME,null)
            "email" -> loggedInPreference.getString(PREFERENCE_USER_EMAIL,null)
            "mobile_no" -> loggedInPreference.getString(PREFERENCE_USER_MOBILE_NO,"")
            "member_id" -> loggedInPreference.getString(PREFERENCE_USER_MEMBER_ID,"")
            "profile_picture" -> loggedInPreference.getString(PREFERENCE_USER_PROFILE_PICTURE,"")
            else -> loggedInPreference.getString(PREFERENCE_USER_NAME,"")
        }
    }
    fun isLoggedIn():Boolean{
        return getUserDetails("name")!=null
//        if (getUserDetails("name")!=null){
//            return true
//        }else{
//            return false
//        }
    }
    fun logoutUser() : Boolean{
        val userEditor = loggedInPreference.edit()
        userEditor.clear()
        userEditor.apply()
        return true
    }
}