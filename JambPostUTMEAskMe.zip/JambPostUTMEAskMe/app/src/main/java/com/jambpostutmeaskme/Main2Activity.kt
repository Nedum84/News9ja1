package com.jambpostutmeaskme

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.google.android.gms.vision.Frame
import com.google.android.gms.vision.text.TextBlock
import com.google.android.gms.vision.text.TextRecognizer
import kotlinx.android.synthetic.main.activity_main2.*

class Main2Activity : AppCompatActivity() {
    lateinit var bitmap:Bitmap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        bitmap = BitmapFactory.decodeResource(this.resources, R.drawable.ocr_sample)
        val txtRecognizer = TextRecognizer.Builder(applicationContext).build()
        if (!txtRecognizer.isOperational){
            // Shows if your Google Play services is not up to date or OCR is not supported for the device
            txtView.text = "Detector dependencies are not yet available"
        }else{
            // Set the bitmap taken to the frame to perform OCR Operations.
            val frame = Frame.Builder().setBitmap(bitmap).build()
            val items = txtRecognizer.detect(frame)
            val strBuilder = StringBuilder()



            for (i in 0 until items.size()){
                val item = items.valueAt(i) as TextBlock
                strBuilder.append(item.value)
                strBuilder.append("/")
            }
            txtView.text = strBuilder.toString()





            tv_result.post {
                val stringBuilder = StringBuilder()
                for (i in 0 until items.size()) {
                    val item = items.valueAt(i)
                    stringBuilder.append(item.value)
                    stringBuilder.append("\n")
                }
                tv_result.text = stringBuilder.toString()
            }





        }
    }
}
