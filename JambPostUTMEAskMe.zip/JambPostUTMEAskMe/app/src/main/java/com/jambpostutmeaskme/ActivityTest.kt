package com.jambpostutmeaskme

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.View
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONException
import org.json.JSONObject

class ActivityTest : AppCompatActivity() {
    private var questionsList = mutableListOf<QuestionDataClassBinder>()
    lateinit var thisContext: Context
    var start_page_from:String = "0"

    val linearLayoutManager = LinearLayoutManager(this)
    val itemList = ArrayList<Item>()
    lateinit var ADAPTER : QuestionsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        thisContext = this

        loadQuestions()

        ADAPTER = QuestionsAdapter(questionsList,thisContext)
        recyclerview.layoutManager = linearLayoutManager
        recyclerview.itemAnimator = DefaultItemAnimator()
        recyclerview.adapter = ADAPTER

        recyclerview.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                // only load more items if it's currently not loading
                if (!ADAPTER.isLoading()) {
//                    if (loadingProgressbar?.visibility == View.VISIBLE) {
                    // only load more items if the last visible item on the screen is the last item
                    Log.d("endlessscroll", "last visible position: ${linearLayoutManager.findLastCompletelyVisibleItemPosition()}, total count: ${linearLayoutManager.itemCount}")
                    if (linearLayoutManager.findLastCompletelyVisibleItemPosition() >= linearLayoutManager.itemCount - 1 ) {


                    Toast.makeText(thisContext, "last visible position: ${linearLayoutManager.findLastCompletelyVisibleItemPosition()}, total count: ${linearLayoutManager.itemCount}", Toast.LENGTH_SHORT).show()
//                        loadingProgressbar?.visibility = View.VISIBLE
                        // add progress bar, the loading footer
                        recyclerview.post {
                            ADAPTER.addFooter()
                        }
                        loadQuestions(true)//loading questions again



                        // load more items after 2 seconds, and remove the loading footer
//                        val handler = Handler()
//                        handler.postDelayed({
//                            ADAPTER.removeFooter()
//                            loadingProgressbar?.visibility = View.GONE
////                            val newItems = ArrayList<Item>()
////                            questionsList.clear()
//                            for (i in questionsList.size..questionsList.size + 19) {
//                                questionsList.add(QuestionDataClassBinder("$i","Footer","Footer","Footer","Footer",
//                                        "Footer","Footer","Footer","Footer","Footer","Footer","Footer",
//                                        "Footer","Footer"))
//                            }
//                            ADAPTER.addItems(questionsList)
//                        }, 5000)

                    }
                }
            }
        })

    }

    private fun loadQuestions(isReloading:Boolean = false){
        start_page_from = if(questionsList.size==0){
            "0"
        }else{
            questionsList.last().question_id
        }

        //creating volley string request
        loadingProgressbar?.visibility = View.VISIBLE
        val stringRequest = object : StringRequest(Request.Method.POST, UrlHolder.URL_GET_QUESTIONS,
                Response.Listener<String> { sub ->
                    loadingProgressbar?.visibility = View.GONE

                    try {
                        val obj = JSONObject(sub)
                        if (!obj.getBoolean("error")) {
//                            questionsList!!.clear()
                            val noOfSub = obj.getJSONArray("topic_questionz_array")

                            if ((noOfSub.length()!=0)){
                                no_question_tag?.visibility = View.GONE


                                if(isReloading){
                                    ADAPTER.removeFooter()//remove footer
                                }
                                val q_data_array = mutableListOf<QuestionDataClassBinder>()
                                for (i in 0 until noOfSub.length()) {
                                    val objectSubject = noOfSub.getJSONObject(i)
                                    q_data_array.add(QuestionDataClassBinder(
                                            objectSubject.getString("question_id"),
                                            objectSubject.getString("subject_id"),
                                            objectSubject.getString("topic_id"),
                                            objectSubject.getString("subject_name"),
                                            objectSubject.getString("topic_name"),
                                            objectSubject.getString("question_sub_or_topic"),
                                            objectSubject.getString("question_type"),
                                            objectSubject.getString("q_posted_time"),
                                            objectSubject.getString("q_img_path"),
                                            objectSubject.getString("q_body"),
                                            objectSubject.getString("q_poster"),
                                            objectSubject.getString("q_poster_id"),
                                            objectSubject.getString("q_no_of_answers"),
                                            objectSubject.getString("q_top_ans_no_of_likes"),
                                            objectSubject.getString("q_top_ans_poster"),
                                            objectSubject.getString("q_top_ans_body")
                                    ))
                                }
//                                questionsList.add(q_data_array)

//                                itemArrayAdapter.addItems(newItems)

//                                ADAPTER.addItems(questionsList)
                                ADAPTER.addItems(q_data_array)


                            }else if(!isReloading){
                                no_question_tag?.visibility = View.VISIBLE
                            }
                        } else {
                            Toast.makeText(this, "An error occurred while loading the subjects", Toast.LENGTH_LONG).show()
                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener { volleyError ->
                    loadingProgressbar?.visibility = View.GONE

                    Toast.makeText(this, "Error in network connection. Swipe down to reload...", Toast.LENGTH_LONG).show()
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String?> {
                val params = HashMap<String, String?>()
                params.put("request_type", "get_questions")
                params.put("start_page_from", start_page_from)
                return params
            }
        }
        VolleySingleton.instance?.addToRequestQueue(stringRequest)//adding request to queue
        //volley interactions end

    }
}
